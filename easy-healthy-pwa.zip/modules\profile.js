// ===================================
// Profile Module
// ===================================

window.ProfileModule = {
    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('profileContent');
        const profile = Storage.get('userProfile') || {};

        container.innerHTML = `
      <div class="tabs">
        <ul class="tab-list">
          <li><button class="tab-button active" onclick="ProfileModule.showTab('identity')">Data Identitas</button></li>
          <li><button class="tab-button" onclick="ProfileModule.showTab('medical')">Riwayat Medis</button></li>
          <li><button class="tab-button" onclick="ProfileModule.showTab('allergies')">Alergi</button></li>
          <li><button class="tab-button" onclick="ProfileModule.showTab('blood')">Golongan Darah</button></li>
        </ul>
      </div>
      
      <!-- Identity Tab -->
      <div id="tab-identity" class="tab-content active">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Data Identitas Pengguna</h3>
          </div>
          <div class="card-body">
            <form id="identityForm" onsubmit="ProfileModule.saveIdentity(event)">
              <div class="grid grid-2">
                <div class="form-group">
                  <label class="form-label required">Nama Lengkap</label>
                  <input type="text" class="form-input" name="name" value="${profile.name || ''}" required>
                </div>
                <div class="form-group">
                  <label class="form-label required">NIK</label>
                  <input type="text" class="form-input" name="nik" value="${profile.nik || ''}" pattern="[0-9]{16}" maxlength="16" required>
                  <small class="form-help">16 digit nomor induk kependudukan</small>
                </div>
                <div class="form-group">
                  <label class="form-label required">Tanggal Lahir</label>
                  <input type="date" class="form-input" name="birthDate" value="${profile.birthDate || ''}" required>
                </div>
                <div class="form-group">
                  <label class="form-label required">Jenis Kelamin</label>
                  <select class="form-select" name="gender" required>
                    <option value="">Pilih</option>
                    <option value="Laki-laki" ${profile.gender === 'Laki-laki' ? 'selected' : ''}>Laki-laki</option>
                    <option value="Perempuan" ${profile.gender === 'Perempuan' ? 'selected' : ''}>Perempuan</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label required">Email</label>
                  <input type="email" class="form-input" name="email" value="${profile.email || ''}" required>
                </div>
                <div class="form-group">
                  <label class="form-label required">Nomor Telepon</label>
                  <input type="tel" class="form-input" name="phone" value="${profile.phone || ''}" required>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label required">Alamat Lengkap</label>
                <textarea class="form-textarea" name="address" required>${profile.address || ''}</textarea>
              </div>
              <button type="submit" class="btn btn-primary btn-lg">
                <i class="fas fa-save"></i> Simpan Data Identitas
              </button>
            </form>
          </div>
        </div>
      </div>
      
      <!-- Medical History Tab -->
      <div id="tab-medical" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Riwayat Penyakit & Pengobatan</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="ProfileModule.addMedicalHistory()">
              <i class="fas fa-plus"></i> Tambah Riwayat
            </button>
            <div id="medicalHistoryList"></div>
          </div>
        </div>
      </div>
      
      <!-- Allergies Tab -->
      <div id="tab-allergies" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Daftar Alergi</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="ProfileModule.addAllergy()">
              <i class="fas fa-plus"></i> Tambah Alergi
            </button>
            <div id="allergiesList"></div>
          </div>
        </div>
      </div>
      
      <!-- Blood Type Tab -->
      <div id="tab-blood" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Golongan Darah</h3>
          </div>
          <div class="card-body">
            <form id="bloodTypeForm" onsubmit="ProfileModule.saveBloodType(event)">
              <div class="form-group">
                <label class="form-label required">Pilih Golongan Darah</label>
                <select class="form-select" name="bloodType" required>
                  <option value="">Pilih Golongan Darah</option>
                  <option value="A+" ${profile.bloodType === 'A+' ? 'selected' : ''}>A+</option>
                  <option value="A-" ${profile.bloodType === 'A-' ? 'selected' : ''}>A-</option>
                  <option value="B+" ${profile.bloodType === 'B+' ? 'selected' : ''}>B+</option>
                  <option value="B-" ${profile.bloodType === 'B-' ? 'selected' : ''}>B-</option>
                  <option value="AB+" ${profile.bloodType === 'AB+' ? 'selected' : ''}>AB+</option>
                  <option value="AB-" ${profile.bloodType === 'AB-' ? 'selected' : ''}>AB-</option>
                  <option value="O+" ${profile.bloodType === 'O+' ? 'selected' : ''}>O+</option>
                  <option value="O-" ${profile.bloodType === 'O-' ? 'selected' : ''}>O-</option>
                </select>
              </div>
              <div class="alert alert-info">
                <strong>Golongan Darah Saat Ini:</strong> ${profile.bloodType || 'Belum diisi'}
              </div>
              <button type="submit" class="btn btn-primary btn-lg">
                <i class="fas fa-save"></i> Simpan Golongan Darah
              </button>
            </form>
          </div>
        </div>
      </div>
    `;

        this.loadMedicalHistory();
        this.loadAllergies();
    },

    showTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    },

    saveIdentity(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        const profile = Storage.get('userProfile') || {};

        formData.forEach((value, key) => {
            profile[key] = value;
        });

        Storage.set('userProfile', profile);
        document.getElementById('userName').textContent = profile.name;
        Utils.showAlert('Data identitas berhasil disimpan!', 'success');
    },

    saveBloodType(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        const profile = Storage.get('userProfile') || {};

        profile.bloodType = formData.get('bloodType');
        Storage.set('userProfile', profile);
        Utils.showAlert('Golongan darah berhasil disimpan!', 'success');
        this.render();
    },

    addMedicalHistory() {
        const content = `
      <form id="medicalHistoryForm">
        <div class="form-group">
          <label class="form-label required">Nama Penyakit</label>
          <input type="text" class="form-input" name="disease" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal Diagnosis</label>
          <input type="date" class="form-input" name="date" required>
        </div>
        <div class="form-group">
          <label class="form-label">Pengobatan</label>
          <textarea class="form-textarea" name="treatment"></textarea>
        </div>
        <div class="form-group">
          <label class="form-label">Catatan</label>
          <textarea class="form-textarea" name="notes"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="ProfileModule.saveMedicalHistory()">Simpan</button>
    `;

        Modal.create('Tambah Riwayat Penyakit', content, { footer });
    },

    saveMedicalHistory() {
        const form = document.getElementById('medicalHistoryForm');
        const formData = new FormData(form);
        const history = Storage.get('medicalHistory') || [];

        const newEntry = {
            id: Utils.generateId(),
            disease: formData.get('disease'),
            date: formData.get('date'),
            treatment: formData.get('treatment'),
            notes: formData.get('notes')
        };

        history.push(newEntry);
        Storage.set('medicalHistory', history);
        Utils.showAlert('Riwayat penyakit berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadMedicalHistory();
    },

    loadMedicalHistory() {
        const container = document.getElementById('medicalHistoryList');
        if (!container) return;

        const history = Storage.get('medicalHistory') || [];

        if (history.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada riwayat penyakit</p>';
            return;
        }

        container.innerHTML = history.map(item => `
      <div class="card mb-2">
        <div class="card-body">
          <h4>${item.disease}</h4>
          <p><strong>Tanggal:</strong> ${Utils.formatDate(item.date)}</p>
          <p><strong>Pengobatan:</strong> ${item.treatment || '-'}</p>
          <p><strong>Catatan:</strong> ${item.notes || '-'}</p>
        </div>
        <div class="card-footer">
          <button class="btn btn-danger btn-sm" onclick="ProfileModule.deleteMedicalHistory('${item.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deleteMedicalHistory(id) {
        if (!Utils.confirm('Hapus riwayat ini?')) return;

        let history = Storage.get('medicalHistory') || [];
        history = history.filter(item => item.id !== id);
        Storage.set('medicalHistory', history);
        Utils.showAlert('Riwayat berhasil dihapus', 'success');
        this.loadMedicalHistory();
    },

    addAllergy() {
        const content = `
      <form id="allergyForm">
        <div class="form-group">
          <label class="form-label required">Nama Alergen</label>
          <input type="text" class="form-input" name="allergen" placeholder="Contoh: Kacang, Seafood, Debu" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Tingkat Keparahan</label>
          <select class="form-select" name="severity" required>
            <option value="">Pilih</option>
            <option value="Ringan">Ringan</option>
            <option value="Sedang">Sedang</option>
            <option value="Berat">Berat</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Reaksi</label>
          <textarea class="form-textarea" name="reaction" placeholder="Contoh: Gatal-gatal, sesak napas"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="ProfileModule.saveAllergy()">Simpan</button>
    `;

        Modal.create('Tambah Alergi', content, { footer });
    },

    saveAllergy() {
        const form = document.getElementById('allergyForm');
        const formData = new FormData(form);
        const allergies = Storage.get('allergies') || [];

        const newAllergy = {
            id: Utils.generateId(),
            allergen: formData.get('allergen'),
            severity: formData.get('severity'),
            reaction: formData.get('reaction')
        };

        allergies.push(newAllergy);
        Storage.set('allergies', allergies);
        Utils.showAlert('Alergi berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadAllergies();
    },

    loadAllergies() {
        const container = document.getElementById('allergiesList');
        if (!container) return;

        const allergies = Storage.get('allergies') || [];

        if (allergies.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada data alergi</p>';
            return;
        }

        const severityBadge = {
            'Ringan': 'badge-info',
            'Sedang': 'badge-warning',
            'Berat': 'badge-danger'
        };

        container.innerHTML = allergies.map(item => `
      <div class="card mb-2">
        <div class="card-body">
          <h4>${item.allergen} <span class="badge ${severityBadge[item.severity]}">${item.severity}</span></h4>
          <p><strong>Reaksi:</strong> ${item.reaction || '-'}</p>
        </div>
        <div class="card-footer">
          <button class="btn btn-danger btn-sm" onclick="ProfileModule.deleteAllergy('${item.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deleteAllergy(id) {
        if (!Utils.confirm('Hapus data alergi ini?')) return;

        let allergies = Storage.get('allergies') || [];
        allergies = allergies.filter(item => item.id !== id);
        Storage.set('allergies', allergies);
        Utils.showAlert('Data alergi berhasil dihapus', 'success');
        this.loadAllergies();
    }
};
