// PWA Installation Handler
let deferredPrompt;
let installButton;

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initInstallHandler);
} else {
    initInstallHandler();
}

function initInstallHandler() {
    // Create install button
    createInstallButton();

    // Register service worker
    registerServiceWorker();

    // Listen for install prompt
    window.addEventListener('beforeinstallprompt', (e) => {
        console.log('[Install] beforeinstallprompt event fired');
        // Prevent the mini-infobar from appearing on mobile
        e.preventDefault();
        // Stash the event so it can be triggered later
        deferredPrompt = e;
        // Show install button
        showInstallButton();
    });

    // Listen for app installed
    window.addEventListener('appinstalled', () => {
        console.log('[Install] App installed successfully');
        hideInstallButton();
        deferredPrompt = null;
        showNotification('✅ Aplikasi berhasil diinstall!', 'success');
    });

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
        console.log('[Install] App is running in standalone mode');
        hideInstallButton();
    }
}

function createInstallButton() {
    // Check if button already exists
    if (document.getElementById('pwa-install-btn')) return;

    const button = document.createElement('button');
    button.id = 'pwa-install-btn';
    button.className = 'pwa-install-button';
    button.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="7 10 12 15 17 10"></polyline>
      <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>
    <span>Install App</span>
  `;
    button.style.display = 'none';
    button.addEventListener('click', handleInstallClick);

    // Add to header
    const header = document.querySelector('header');
    if (header) {
        header.appendChild(button);
    } else {
        document.body.insertBefore(button, document.body.firstChild);
    }

    installButton = button;
}

function showInstallButton() {
    if (installButton) {
        installButton.style.display = 'flex';
    }
}

function hideInstallButton() {
    if (installButton) {
        installButton.style.display = 'none';
    }
}

async function handleInstallClick() {
    if (!deferredPrompt) {
        console.log('[Install] No install prompt available');
        return;
    }

    // Show the install prompt
    deferredPrompt.prompt();

    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`[Install] User response: ${outcome}`);

    if (outcome === 'accepted') {
        console.log('[Install] User accepted the install prompt');
    } else {
        console.log('[Install] User dismissed the install prompt');
    }

    // Clear the deferredPrompt
    deferredPrompt = null;
    hideInstallButton();
}

async function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.register('./sw.js');
            console.log('[Service Worker] Registered successfully:', registration.scope);

            // Check for updates
            registration.addEventListener('updatefound', () => {
                const newWorker = registration.installing;
                console.log('[Service Worker] Update found');

                newWorker.addEventListener('statechange', () => {
                    if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                        console.log('[Service Worker] New version available');
                        showUpdateNotification();
                    }
                });
            });

        } catch (error) {
            console.error('[Service Worker] Registration failed:', error);
        }
    } else {
        console.log('[Service Worker] Not supported in this browser');
    }
}

function showUpdateNotification() {
    const notification = document.createElement('div');
    notification.className = 'update-notification';
    notification.innerHTML = `
    <div class="update-content">
      <p>🎉 Update baru tersedia!</p>
      <button onclick="window.location.reload()">Refresh</button>
    </div>
  `;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add CSS for install button and notifications
const style = document.createElement('style');
style.textContent = `
  .pwa-install-button {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: linear-gradient(135deg, #2d8659 0%, #1e5a3d 100%);
    color: white;
    border: none;
    border-radius: 50px;
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(45, 134, 89, 0.4);
    display: flex;
    align-items: center;
    gap: 8px;
    z-index: 9999;
    transition: all 0.3s ease;
    animation: slideInUp 0.5s ease;
  }

  .pwa-install-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(45, 134, 89, 0.5);
  }

  .pwa-install-button:active {
    transform: translateY(0);
  }

  .pwa-install-button svg {
    animation: bounce 2s infinite;
  }

  @keyframes slideInUp {
    from {
      transform: translateY(100px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }

  @keyframes bounce {
    0%, 100% {
      transform: translateY(0);
    }
    50% {
      transform: translateY(-5px);
    }
  }

  .update-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
    padding: 16px 20px;
    z-index: 10000;
    transform: translateX(400px);
    transition: transform 0.3s ease;
  }

  .update-notification.show {
    transform: translateX(0);
  }

  .update-content {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .update-content p {
    margin: 0;
    font-weight: 600;
    color: #333;
  }

  .update-content button {
    background: #2d8659;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .update-content button:hover {
    background: #1e5a3d;
  }

  .notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: white;
    border-radius: 8px;
    padding: 12px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 10000;
    transform: translateX(400px);
    transition: transform 0.3s ease;
  }

  .notification.show {
    transform: translateX(0);
  }

  .notification-success {
    border-left: 4px solid #2d8659;
  }

  @media (max-width: 768px) {
    .pwa-install-button {
      bottom: 80px;
      right: 16px;
      font-size: 13px;
      padding: 10px 20px;
    }
  }
`;
document.head.appendChild(style);
