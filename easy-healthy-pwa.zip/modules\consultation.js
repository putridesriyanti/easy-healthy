// ===================================
// Consultation Module
// ===================================

window.ConsultationModule = {
    currentChat: null,

    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('consultationContent');

        container.innerHTML = `
      <div class="tabs">
        <ul class="tab-list">
          <li><button class="tab-button active" onclick="ConsultationModule.showTab('chat')">Chat</button></li>
          <li><button class="tab-button" onclick="ConsultationModule.showTab('video')">Video Call</button></li>
          <li><button class="tab-button" onclick="ConsultationModule.showTab('photos')">Kirim Foto</button></li>
          <li><button class="tab-button" onclick="ConsultationModule.showTab('schedule')">Jadwal</button></li>
        </ul>
      </div>
      
      <!-- Chat Tab -->
      <div id="tab-chat" class="tab-content active">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Chat dengan Tenaga Kesehatan</h3>
          </div>
          <div class="card-body">
            <div id="chatMessages" style="height: 400px; overflow-y: auto; border: 2px solid var(--light-gray); border-radius: var(--radius-md); padding: var(--spacing-md); margin-bottom: var(--spacing-md); background: var(--off-white);">
              <p class="text-center" style="color: var(--dark-gray);">Pilih atau mulai percakapan baru</p>
            </div>
            <form id="chatForm" onsubmit="ConsultationModule.sendMessage(event)">
              <div class="form-group">
                <div style="display: flex; gap: var(--spacing-md);">
                  <input type="text" class="form-input" id="chatInput" placeholder="Ketik pesan Anda..." required>
                  <button type="submit" class="btn btn-primary">
                    <i class="fas fa-paper-plane"></i> Kirim
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      
      <!-- Video Call Tab -->
      <div id="tab-video" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Video Call dengan Dokter</h3>
          </div>
          <div class="card-body">
            <div class="alert alert-info">
              <i class="fas fa-info-circle"></i> Fitur video call memerlukan jadwal konsultasi terlebih dahulu
            </div>
            <div style="background: var(--dark-gray); height: 400px; border-radius: var(--radius-lg); display: flex; align-items: center; justify-content: center; margin-bottom: var(--spacing-lg);">
              <div style="text-align: center; color: var(--white);">
                <i class="fas fa-video" style="font-size: 4rem; margin-bottom: var(--spacing-md);"></i>
                <p>Video call belum dimulai</p>
              </div>
            </div>
            <div style="display: flex; gap: var(--spacing-md); justify-content: center;">
              <button class="btn btn-success btn-lg" onclick="Utils.showAlert('Fitur video call akan tersedia setelah jadwal konsultasi dikonfirmasi', 'info')">
                <i class="fas fa-video"></i> Mulai Video Call
              </button>
              <button class="btn btn-danger btn-lg" disabled>
                <i class="fas fa-phone-slash"></i> Akhiri
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Photos Tab -->
      <div id="tab-photos" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Kirim Foto Hasil Pemeriksaan</h3>
          </div>
          <div class="card-body">
            <form id="photoForm" onsubmit="ConsultationModule.uploadPhoto(event)">
              <div class="form-group">
                <label class="form-label required">Pilih Foto</label>
                <input type="file" class="form-input" name="photo" accept="image/*" required>
              </div>
              <div class="form-group">
                <label class="form-label required">Keterangan</label>
                <textarea class="form-textarea" name="description" placeholder="Jelaskan tentang foto yang dikirim" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary btn-lg">
                <i class="fas fa-upload"></i> Upload Foto
              </button>
            </form>
            <hr>
            <h4>Foto yang Dikirim</h4>
            <div id="photosList"></div>
          </div>
        </div>
      </div>
      
      <!-- Schedule Tab -->
      <div id="tab-schedule" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Jadwal Konsultasi</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="ConsultationModule.addSchedule()">
              <i class="fas fa-plus"></i> Buat Jadwal Baru
            </button>
            <div id="scheduleList"></div>
          </div>
        </div>
      </div>
    `;

        this.loadChat();
        this.loadPhotos();
        this.loadSchedules();
    },

    showTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    },

    sendMessage(event) {
        event.preventDefault();
        const input = document.getElementById('chatInput');
        const message = input.value.trim();

        if (!message) return;

        const messages = Storage.get('chatMessages') || [];
        messages.push({
            id: Utils.generateId(),
            text: message,
            sender: 'user',
            timestamp: new Date().toISOString()
        });

        Storage.set('chatMessages', messages);
        input.value = '';
        this.loadChat();

        // Simulate response
        setTimeout(() => {
            const responses = [
                'Terima kasih atas pesannya. Dokter akan segera merespons.',
                'Pesan Anda telah diterima. Mohon tunggu sebentar.',
                'Kami akan menghubungkan Anda dengan tenaga kesehatan yang tersedia.'
            ];
            const response = responses[Math.floor(Math.random() * responses.length)];

            const messages = Storage.get('chatMessages') || [];
            messages.push({
                id: Utils.generateId(),
                text: response,
                sender: 'doctor',
                timestamp: new Date().toISOString()
            });
            Storage.set('chatMessages', messages);
            this.loadChat();
        }, 1000);
    },

    loadChat() {
        const container = document.getElementById('chatMessages');
        if (!container) return;

        const messages = Storage.get('chatMessages') || [];

        if (messages.length === 0) {
            container.innerHTML = '<p class="text-center" style="color: var(--dark-gray);">Belum ada percakapan</p>';
            return;
        }

        container.innerHTML = messages.map(msg => `
      <div style="margin-bottom: var(--spacing-md); text-align: ${msg.sender === 'user' ? 'right' : 'left'};">
        <div style="display: inline-block; max-width: 70%; padding: var(--spacing-md); border-radius: var(--radius-md); background: ${msg.sender === 'user' ? 'var(--primary-green)' : 'var(--white)'}; color: ${msg.sender === 'user' ? 'var(--white)' : 'var(--text-dark)'}; box-shadow: var(--shadow-sm);">
          <p style="margin: 0;">${msg.text}</p>
          <small style="opacity: 0.7; font-size: var(--font-size-xs);">${Utils.formatTime(msg.timestamp)}</small>
        </div>
      </div>
    `).join('');

        container.scrollTop = container.scrollHeight;
    },

    uploadPhoto(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);

        const photos = Storage.get('consultationPhotos') || [];
        photos.push({
            id: Utils.generateId(),
            description: formData.get('description'),
            uploadDate: new Date().toISOString(),
            fileName: formData.get('photo').name
        });

        Storage.set('consultationPhotos', photos);
        Utils.showAlert('Foto berhasil diupload!', 'success');
        form.reset();
        this.loadPhotos();
    },

    loadPhotos() {
        const container = document.getElementById('photosList');
        if (!container) return;

        const photos = Storage.get('consultationPhotos') || [];

        if (photos.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada foto yang diupload</p>';
            return;
        }

        container.innerHTML = photos.map(photo => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-image"></i> ${photo.fileName}</h4>
          <p>${photo.description}</p>
          <small>Diupload: ${Utils.formatDateTime(photo.uploadDate)}</small>
        </div>
        <div class="card-footer">
          <button class="btn btn-danger btn-sm" onclick="ConsultationModule.deletePhoto('${photo.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deletePhoto(id) {
        if (!Utils.confirm('Hapus foto ini?')) return;

        let photos = Storage.get('consultationPhotos') || [];
        photos = photos.filter(p => p.id !== id);
        Storage.set('consultationPhotos', photos);
        Utils.showAlert('Foto berhasil dihapus', 'success');
        this.loadPhotos();
    },

    addSchedule() {
        const content = `
      <form id="scheduleForm">
        <div class="form-group">
          <label class="form-label required">Tanggal Konsultasi</label>
          <input type="date" class="form-input" name="date" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Waktu</label>
          <input type="time" class="form-input" name="time" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Dokter/Tenaga Kesehatan</label>
          <input type="text" class="form-input" name="doctor" placeholder="Nama dokter" required>
        </div>
        <div class="form-group">
          <label class="form-label">Keluhan</label>
          <textarea class="form-textarea" name="complaint" placeholder="Jelaskan keluhan Anda"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="ConsultationModule.saveSchedule()">Simpan</button>
    `;

        Modal.create('Buat Jadwal Konsultasi', content, { footer });
    },

    saveSchedule() {
        const form = document.getElementById('scheduleForm');
        const formData = new FormData(form);
        const schedules = Storage.get('consultationSchedules') || [];

        schedules.push({
            id: Utils.generateId(),
            date: formData.get('date'),
            time: formData.get('time'),
            doctor: formData.get('doctor'),
            complaint: formData.get('complaint'),
            status: 'Terjadwal'
        });

        Storage.set('consultationSchedules', schedules);
        Utils.showAlert('Jadwal konsultasi berhasil dibuat!', 'success');
        Modal.close(form);
        this.loadSchedules();
    },

    loadSchedules() {
        const container = document.getElementById('scheduleList');
        if (!container) return;

        const schedules = Storage.get('consultationSchedules') || [];

        if (schedules.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada jadwal konsultasi</p>';
            return;
        }

        container.innerHTML = schedules.map(schedule => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-calendar"></i> ${Utils.formatDate(schedule.date)} - ${schedule.time}</h4>
          <p><strong>Dokter:</strong> ${schedule.doctor}</p>
          <p><strong>Keluhan:</strong> ${schedule.complaint || '-'}</p>
          <span class="badge badge-info">${schedule.status}</span>
        </div>
        <div class="card-footer">
          <button class="btn btn-danger btn-sm" onclick="ConsultationModule.deleteSchedule('${schedule.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deleteSchedule(id) {
        if (!Utils.confirm('Hapus jadwal ini?')) return;

        let schedules = Storage.get('consultationSchedules') || [];
        schedules = schedules.filter(s => s.id !== id);
        Storage.set('consultationSchedules', schedules);
        Utils.showAlert('Jadwal berhasil dihapus', 'success');
        this.loadSchedules();
    }
};
