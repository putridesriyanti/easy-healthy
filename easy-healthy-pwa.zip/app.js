// ===================================
// Easy Healthy - Main Application
// ===================================

// Storage Manager
const Storage = {
    get(key) {
        try {
            const data = localStorage.getItem(`easyHealthy_${key}`);
            return data ? JSON.parse(data) : null;
        } catch (e) {
            console.error('Error reading from storage:', e);
            return null;
        }
    },

    set(key, value) {
        try {
            localStorage.setItem(`easyHealthy_${key}`, JSON.stringify(value));
            return true;
        } catch (e) {
            console.error('Error writing to storage:', e);
            return false;
        }
    },

    remove(key) {
        try {
            localStorage.removeItem(`easyHealthy_${key}`);
            return true;
        } catch (e) {
            console.error('Error removing from storage:', e);
            return false;
        }
    },

    clear() {
        try {
            const keys = Object.keys(localStorage);
            keys.forEach(key => {
                if (key.startsWith('easyHealthy_')) {
                    localStorage.removeItem(key);
                }
            });
            return true;
        } catch (e) {
            console.error('Error clearing storage:', e);
            return false;
        }
    }
};

// Utility Functions
const Utils = {
    formatDate(date) {
        if (!(date instanceof Date)) {
            date = new Date(date);
        }
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString('id-ID', options);
    },

    formatTime(date) {
        if (!(date instanceof Date)) {
            date = new Date(date);
        }
        return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    },

    formatDateTime(date) {
        return `${this.formatDate(date)} ${this.formatTime(date)}`;
    },

    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    showAlert(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        alertDiv.textContent = message;
        alertDiv.style.position = 'fixed';
        alertDiv.style.top = '100px';
        alertDiv.style.right = '20px';
        alertDiv.style.zIndex = '3000';
        alertDiv.style.minWidth = '300px';
        alertDiv.style.animation = 'slideInRight 0.3s ease-out';

        document.body.appendChild(alertDiv);

        setTimeout(() => {
            alertDiv.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => alertDiv.remove(), 300);
        }, 3000);
    },

    confirm(message) {
        return window.confirm(message);
    },

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    validatePhone(phone) {
        const re = /^[\d\s\-\+\(\)]+$/;
        return re.test(phone) && phone.replace(/\D/g, '').length >= 10;
    }
};

// Navigation Manager
const Navigation = {
    init() {
        const navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const sectionId = link.getAttribute('data-section');
                this.navigateTo(sectionId);
            });
        });

        // Handle browser back/forward
        window.addEventListener('hashchange', () => {
            const hash = window.location.hash.substring(1);
            if (hash) {
                this.navigateTo(hash, false);
            }
        });

        // Load initial section from URL hash
        const initialHash = window.location.hash.substring(1);
        if (initialHash) {
            this.navigateTo(initialHash, false);
        }
    },

    navigateTo(sectionId, updateHash = true) {
        // Hide all sections
        const sections = document.querySelectorAll('.section');
        sections.forEach(section => section.classList.remove('active'));

        // Show target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');

            // Update navigation active state
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                if (link.getAttribute('data-section') === sectionId) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            });

            // Update URL hash
            if (updateHash) {
                window.location.hash = sectionId;
            }

            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });

            // Trigger module initialization if needed
            this.initializeModule(sectionId);
        }
    },

    initializeModule(sectionId) {
        // Call module-specific initialization functions
        const initFunctions = {
            'profile': () => window.ProfileModule && window.ProfileModule.init(),
            'consultation': () => window.ConsultationModule && window.ConsultationModule.init(),
            'registration': () => window.RegistrationModule && window.RegistrationModule.init(),
            'monitoring': () => window.MonitoringModule && window.MonitoringModule.init(),
            'reminders': () => window.RemindersModule && window.RemindersModule.init(),
            'education': () => window.EducationModule && window.EducationModule.init(),
            'records': () => window.RecordsModule && window.RecordsModule.init(),
            'facilities': () => window.FacilitiesModule && window.FacilitiesModule.init(),
            'security': () => window.SecurityModule && window.SecurityModule.init()
        };

        if (initFunctions[sectionId]) {
            initFunctions[sectionId]();
        }
    }
};

// Modal Manager
const Modal = {
    create(title, content, options = {}) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title">${title}</h3>
          <button class="modal-close" onclick="Modal.close(this)">&times;</button>
        </div>
        <div class="modal-body">
          ${content}
        </div>
        ${options.footer ? `<div class="modal-footer">${options.footer}</div>` : ''}
      </div>
    `;

        document.body.appendChild(modal);
        setTimeout(() => modal.classList.add('active'), 10);

        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.close(modal);
            }
        });

        return modal;
    },

    close(element) {
        const modal = element.closest('.modal');
        if (modal) {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 300);
        }
    }
};

// Global navigation function
function navigateTo(sectionId) {
    Navigation.navigateTo(sectionId);
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    Navigation.init();

    // Load user info
    const userProfile = Storage.get('userProfile');
    if (userProfile && userProfile.name) {
        document.getElementById('userName').textContent = userProfile.name;
    }

    console.log('Easy Healthy App initialized successfully!');
});

// Add animation styles dynamically
const style = document.createElement('style');
style.textContent = `
  @keyframes slideInRight {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOutRight {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
`;
document.head.appendChild(style);
