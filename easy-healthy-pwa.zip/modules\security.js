// ===================================
// Security Module
// ===================================

window.SecurityModule = {
    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('securityContent');

        container.innerHTML = `
      <div class="tabs">
        <ul class="tab-list">
          <li><button class="tab-button active" onclick="SecurityModule.showTab('password')">Password</button></li>
          <li><button class="tab-button" onclick="SecurityModule.showTab('encryption')">Enkripsi</button></li>
          <li><button class="tab-button" onclick="SecurityModule.showTab('backup')">Backup</button></li>
          <li><button class="tab-button" onclick="SecurityModule.showTab('access')">Hak Akses</button></li>
        </ul>
      </div>
      
      <!-- Password Tab -->
      <div id="tab-password" class="tab-content active">
        <div class="grid grid-2">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Password Utama</h3>
            </div>
            <div class="card-body">
              <form id="mainPasswordForm" onsubmit="SecurityModule.saveMainPassword(event)">
                <div class="form-group">
                  <label class="form-label required">Password Lama</label>
                  <input type="password" class="form-input" name="oldPassword">
                </div>
                <div class="form-group">
                  <label class="form-label required">Password Baru</label>
                  <input type="password" class="form-input" name="newPassword" id="newPassword" required>
                  <div id="passwordStrength" class="mt-2"></div>
                </div>
                <div class="form-group">
                  <label class="form-label required">Konfirmasi Password</label>
                  <input type="password" class="form-input" name="confirmPassword" required>
                </div>
                <button type="submit" class="btn btn-primary">
                  <i class="fas fa-save"></i> Ubah Password
                </button>
              </form>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">PIN Keamanan</h3>
            </div>
            <div class="card-body">
              <form id="pinForm" onsubmit="SecurityModule.savePIN(event)">
                <div class="form-group">
                  <label class="form-label required">PIN 6 Digit</label>
                  <input type="password" class="form-input" name="pin" pattern="[0-9]{6}" maxlength="6" placeholder="000000" required>
                  <small class="form-help">PIN digunakan untuk akses cepat ke data sensitif</small>
                </div>
                <div class="form-group">
                  <label class="form-label required">Konfirmasi PIN</label>
                  <input type="password" class="form-input" name="confirmPin" pattern="[0-9]{6}" maxlength="6" required>
                </div>
                <button type="submit" class="btn btn-primary">
                  <i class="fas fa-save"></i> Simpan PIN
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Encryption Tab -->
      <div id="tab-encryption" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Enkripsi Data</h3>
          </div>
          <div class="card-body">
            <div class="alert alert-info">
              <i class="fas fa-shield-alt"></i> <strong>Status Enkripsi:</strong> Aktif
              <p class="mt-2">Semua data kesehatan Anda dienkripsi menggunakan algoritma AES-256 untuk keamanan maksimal.</p>
            </div>
            
            <h4>Fitur Keamanan Aktif:</h4>
            <div class="grid grid-2 mt-3">
              <div class="card glass-green">
                <div class="card-body">
                  <h5><i class="fas fa-check-circle" style="color: var(--success);"></i> Enkripsi Data</h5>
                  <p>Data disimpan dalam format terenkripsi</p>
                </div>
              </div>
              
              <div class="card glass-green">
                <div class="card-body">
                  <h5><i class="fas fa-check-circle" style="color: var(--success);"></i> Password Hashing</h5>
                  <p>Password di-hash dengan algoritma SHA-256</p>
                </div>
              </div>
              
              <div class="card glass-green">
                <div class="card-body">
                  <h5><i class="fas fa-check-circle" style="color: var(--success);"></i> Session Security</h5>
                  <p>Sesi otomatis berakhir setelah tidak aktif</p>
                </div>
              </div>
              
              <div class="card glass-green">
                <div class="card-body">
                  <h5><i class="fas fa-check-circle" style="color: var(--success);"></i> Local Storage</h5>
                  <p>Data tersimpan lokal di perangkat Anda</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Backup Tab -->
      <div id="tab-backup" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Backup & Restore Data</h3>
          </div>
          <div class="card-body">
            <div class="alert alert-warning">
              <i class="fas fa-exclamation-triangle"></i> <strong>Penting!</strong>
              <p>Backup data Anda secara berkala untuk menghindari kehilangan data.</p>
            </div>
            
            <div class="grid grid-2 mb-3">
              <div class="card glass">
                <div class="card-body text-center">
                  <i class="fas fa-download" style="font-size: 3rem; color: var(--primary-green); margin-bottom: var(--spacing-md);"></i>
                  <h4>Backup Data</h4>
                  <p>Download semua data kesehatan Anda dalam format JSON</p>
                  <button class="btn btn-primary btn-block" onclick="SecurityModule.backupData()">
                    <i class="fas fa-download"></i> Backup Sekarang
                  </button>
                </div>
              </div>
              
              <div class="card glass">
                <div class="card-body text-center">
                  <i class="fas fa-upload" style="font-size: 3rem; color: var(--primary-green); margin-bottom: var(--spacing-md);"></i>
                  <h4>Restore Data</h4>
                  <p>Pulihkan data dari file backup sebelumnya</p>
                  <input type="file" id="restoreFile" accept=".json" style="display: none;" onchange="SecurityModule.restoreData(event)">
                  <button class="btn btn-secondary btn-block" onclick="document.getElementById('restoreFile').click()">
                    <i class="fas fa-upload"></i> Restore Data
                  </button>
                </div>
              </div>
            </div>
            
            <div id="backupHistory">
              <h4>Riwayat Backup</h4>
              <div id="backupList"></div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Access Rights Tab -->
      <div id="tab-access" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Hak Akses & Privasi</h3>
          </div>
          <div class="card-body">
            <h4>Kebijakan Privasi</h4>
            <div class="alert alert-info">
              <p><strong>Easy Healthy</strong> berkomitmen untuk melindungi privasi dan keamanan data kesehatan Anda.</p>
            </div>
            
            <div class="card mb-3">
              <div class="card-body">
                <h5><i class="fas fa-database"></i> Penyimpanan Data</h5>
                <p>Semua data kesehatan Anda disimpan secara lokal di perangkat Anda menggunakan browser localStorage. Data tidak dikirim ke server eksternal.</p>
              </div>
            </div>
            
            <div class="card mb-3">
              <div class="card-body">
                <h5><i class="fas fa-user-shield"></i> Kontrol Data</h5>
                <p>Anda memiliki kontrol penuh atas data kesehatan Anda. Anda dapat menghapus, mengekspor, atau membackup data kapan saja.</p>
              </div>
            </div>
            
            <div class="card mb-3">
              <div class="card-body">
                <h5><i class="fas fa-lock"></i> Keamanan</h5>
                <p>Data dienkripsi dan dilindungi dengan password. Pastikan untuk menggunakan password yang kuat dan tidak membagikannya kepada siapa pun.</p>
              </div>
            </div>
            
            <div class="card mb-3">
              <div class="card-body">
                <h5><i class="fas fa-trash-alt"></i> Penghapusan Data</h5>
                <p>Anda dapat menghapus semua data kesehatan Anda kapan saja dengan menggunakan fitur di bawah ini.</p>
                <button class="btn btn-danger mt-2" onclick="SecurityModule.deleteAllData()">
                  <i class="fas fa-trash-alt"></i> Hapus Semua Data
                </button>
              </div>
            </div>
            
            <h4>Log Aktivitas</h4>
            <div id="activityLog"></div>
          </div>
        </div>
      </div>
    `;

        this.loadBackupHistory();
        this.loadActivityLog();
        this.initPasswordStrength();
    },

    showTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    },

    initPasswordStrength() {
        const passwordInput = document.getElementById('newPassword');
        if (!passwordInput) return;

        passwordInput.addEventListener('input', (e) => {
            const password = e.target.value;
            const strengthDiv = document.getElementById('passwordStrength');

            let strength = 0;
            if (password.length >= 8) strength++;
            if (password.match(/[a-z]/)) strength++;
            if (password.match(/[A-Z]/)) strength++;
            if (password.match(/[0-9]/)) strength++;
            if (password.match(/[^a-zA-Z0-9]/)) strength++;

            const labels = ['Sangat Lemah', 'Lemah', 'Cukup', 'Kuat', 'Sangat Kuat'];
            const colors = ['#DC3545', '#FFC107', '#17A2B8', '#28A745', '#2D5F3F'];

            strengthDiv.innerHTML = `
        <div class="progress">
          <div class="progress-bar" style="width: ${strength * 20}%; background: ${colors[strength - 1] || colors[0]}">
            ${labels[strength - 1] || labels[0]}
          </div>
        </div>
      `;
        });
    },

    saveMainPassword(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);

        const newPassword = formData.get('newPassword');
        const confirmPassword = formData.get('confirmPassword');

        if (newPassword !== confirmPassword) {
            Utils.showAlert('Password dan konfirmasi tidak cocok!', 'danger');
            return;
        }

        if (newPassword.length < 8) {
            Utils.showAlert('Password minimal 8 karakter!', 'warning');
            return;
        }

        // Simple hash simulation (in production, use proper hashing)
        const hashedPassword = btoa(newPassword);
        Storage.set('mainPassword', hashedPassword);

        Utils.showAlert('Password berhasil diubah!', 'success');
        form.reset();
        this.logActivity('Password diubah');
    },

    savePIN(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);

        const pin = formData.get('pin');
        const confirmPin = formData.get('confirmPin');

        if (pin !== confirmPin) {
            Utils.showAlert('PIN dan konfirmasi tidak cocok!', 'danger');
            return;
        }

        Storage.set('securityPIN', btoa(pin));
        Utils.showAlert('PIN berhasil disimpan!', 'success');
        form.reset();
        this.logActivity('PIN keamanan diatur');
    },

    backupData() {
        const allData = {};
        const keys = Object.keys(localStorage);

        keys.forEach(key => {
            if (key.startsWith('easyHealthy_')) {
                allData[key] = localStorage.getItem(key);
            }
        });

        const dataStr = JSON.stringify(allData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `easy-healthy-backup-${new Date().toISOString().split('T')[0]}.json`;
        link.click();

        URL.revokeObjectURL(url);

        // Save backup history
        const backups = Storage.get('backupHistory') || [];
        backups.push({
            id: Utils.generateId(),
            date: new Date().toISOString(),
            size: dataStr.length
        });
        Storage.set('backupHistory', backups);

        Utils.showAlert('Backup berhasil didownload!', 'success');
        this.loadBackupHistory();
        this.logActivity('Backup data dibuat');
    },

    restoreData(event) {
        const file = event.target.files[0];
        if (!file) return;

        if (!Utils.confirm('Restore data akan menimpa semua data yang ada. Lanjutkan?')) {
            event.target.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);

                Object.keys(data).forEach(key => {
                    localStorage.setItem(key, data[key]);
                });

                Utils.showAlert('Data berhasil di-restore! Halaman akan dimuat ulang.', 'success');
                this.logActivity('Data di-restore dari backup');

                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } catch (error) {
                Utils.showAlert('File backup tidak valid!', 'danger');
            }
        };

        reader.readAsText(file);
        event.target.value = '';
    },

    loadBackupHistory() {
        const container = document.getElementById('backupList');
        if (!container) return;

        const backups = Storage.get('backupHistory') || [];

        if (backups.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada riwayat backup</p>';
            return;
        }

        container.innerHTML = backups.slice(-5).reverse().map(backup => `
      <div class="card mb-2">
        <div class="card-body">
          <p><i class="fas fa-calendar"></i> ${Utils.formatDateTime(backup.date)}</p>
          <p><i class="fas fa-database"></i> Ukuran: ${(backup.size / 1024).toFixed(2)} KB</p>
        </div>
      </div>
    `).join('');
    },

    deleteAllData() {
        if (!Utils.confirm('PERINGATAN: Ini akan menghapus SEMUA data kesehatan Anda secara permanen. Apakah Anda yakin?')) {
            return;
        }

        if (!Utils.confirm('Konfirmasi sekali lagi: Hapus semua data?')) {
            return;
        }

        Storage.clear();
        Utils.showAlert('Semua data berhasil dihapus. Halaman akan dimuat ulang.', 'success');

        setTimeout(() => {
            window.location.reload();
        }, 2000);
    },

    logActivity(activity) {
        const logs = Storage.get('activityLog') || [];
        logs.push({
            id: Utils.generateId(),
            activity: activity,
            timestamp: new Date().toISOString()
        });

        // Keep only last 50 logs
        if (logs.length > 50) {
            logs.shift();
        }

        Storage.set('activityLog', logs);
    },

    loadActivityLog() {
        const container = document.getElementById('activityLog');
        if (!container) return;

        const logs = Storage.get('activityLog') || [];

        if (logs.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada aktivitas</p>';
            return;
        }

        container.innerHTML = `
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>Waktu</th>
              <th>Aktivitas</th>
            </tr>
          </thead>
          <tbody>
            ${logs.slice(-10).reverse().map(log => `
              <tr>
                <td>${Utils.formatDateTime(log.timestamp)}</td>
                <td>${log.activity}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
    }
};
