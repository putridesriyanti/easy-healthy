# 🏥 Easy Healthy - Panduan Penggunaan Offline

Selamat datang! Anda telah berhasil mendownload **Easy Healthy Web App** untuk penggunaan offline.

## 📋 Cara Menggunakan

### ⭐ Metode 1: Install sebagai Aplikasi (Recommended!)

Aplikasi ini adalah **Progressive Web App (PWA)** yang bisa diinstall di semua device!

1. **Buka file `start.html`** dengan double-click
2. Aplikasi akan terbuka di browser
3. **Klik tombol "Install App"** yang muncul di pojok kanan bawah
4. Atau klik icon install di address bar browser
5. **Selesai!** Aplikasi akan terinstall seperti aplikasi native

**Keuntungan Install:**
- ✅ Buka seperti aplikasi native (tidak ada address bar)
- ✅ Icon di Start Menu / Home Screen
- ✅ Akses lebih cepat
- ✅ Notifikasi update otomatis

📖 **Panduan lengkap**: Lihat file `INSTALL-GUIDE.md` untuk instruksi detail semua platform

### Metode 2: Langsung Buka di Browser

1. **Buka file `start.html`** dengan double-click
2. Aplikasi akan terbuka di browser default Anda
3. Selesai! Aplikasi siap digunakan

### Metode 2: Pilih Browser Tertentu

1. **Klik kanan** pada file `index.html`
2. Pilih **"Open with"** atau **"Buka dengan"**
3. Pilih browser favorit Anda (Chrome, Firefox, Edge, dll)
4. Aplikasi akan terbuka di browser yang dipilih

## 🌐 Browser yang Didukung

Aplikasi ini kompatibel dengan semua browser modern:

- ✅ Google Chrome (Recommended)
- ✅ Microsoft Edge
- ✅ Mozilla Firefox
- ✅ Safari
- ✅ Opera
- ✅ Brave

## 💾 Penyimpanan Data

**PENTING:** Semua data yang Anda masukkan (profil kesehatan, monitoring, pengingat, dll) akan disimpan di **localStorage browser** di perangkat Anda.

### Catatan Penting:
- ✅ Data tersimpan **lokal** di perangkat Anda
- ✅ Data **tidak dikirim** ke server manapun
- ✅ Data **tetap ada** meskipun browser ditutup
- ⚠️ Data akan **hilang** jika Anda clear browser data/cache
- ⚠️ Data **tidak sync** antar perangkat

### Backup Data:
Untuk backup data Anda:
1. Buka menu **Keamanan** di aplikasi
2. Gunakan fitur **Export Data**
3. Simpan file backup di tempat aman
4. Untuk restore, gunakan fitur **Import Data**

## 📱 Menggunakan di Perangkat Lain

### Di Komputer Lain:
1. Copy seluruh folder aplikasi ini ke komputer lain
2. Buka `start.html` atau `index.html`
3. Selesai!

### Di Smartphone/Tablet:
1. Copy folder ke smartphone (via USB, cloud storage, dll)
2. Gunakan file manager untuk menemukan file `index.html`
3. Tap file tersebut untuk membuka di browser
4. Atau gunakan browser untuk membuka file (File → Open File)

## 🔧 Troubleshooting

### Aplikasi tidak muncul dengan benar?
- Pastikan semua file dalam folder ini utuh (jangan hapus apapun)
- Coba browser lain
- Pastikan JavaScript enabled di browser

### Data hilang?
- Jangan clear browser cache/data
- Gunakan fitur backup di menu Keamanan
- Pastikan selalu buka dari lokasi folder yang sama

### Gambar/Logo tidak muncul?
- Pastikan folder `assets` ada dan lengkap
- Jangan pindahkan file HTML keluar dari folder ini

## 📂 Struktur Folder

```
easy-healthy-offline/
├── index.html          # File utama aplikasi
├── start.html          # Launcher (buka file ini)
├── styles.css          # Styling aplikasi
├── app.js              # Logika utama
├── assets/             # Gambar dan logo
│   └── logo.png
├── modules/            # Modul-modul fitur
│   ├── profile.js
│   ├── consultation.js
│   ├── registration.js
│   ├── monitoring.js
│   ├── reminders.js
│   ├── education.js
│   ├── records.js
│   ├── facilities.js
│   └── security.js
└── README.md           # File ini
```

**JANGAN** hapus atau pindahkan file apapun dari struktur ini!

## 🌟 Fitur Aplikasi

Aplikasi ini memiliki 9 modul lengkap:

1. **Profil Kesehatan** - Kelola data pribadi dan riwayat kesehatan
2. **Konsultasi Online** - Chat dengan tenaga kesehatan
3. **Pendaftaran Online** - Daftar pemeriksaan kesehatan
4. **Monitoring Kesehatan** - Pantau tekanan darah, gula darah, dll
5. **Pengingat Kesehatan** - Reminder minum obat dan jadwal kontrol
6. **Edukasi Kesehatan** - Artikel dan tips kesehatan
7. **Rekam Medis Digital** - Simpan hasil lab dan resep
8. **Pencarian Fasilitas** - Cari rumah sakit dan klinik terdekat
9. **Keamanan Data** - Backup dan restore data

## 🔒 Privasi & Keamanan

- ✅ Semua data tersimpan **lokal** di perangkat Anda
- ✅ **Tidak ada** koneksi ke server eksternal
- ✅ **Tidak ada** tracking atau analytics
- ✅ Data Anda **100% pribadi**

## 📞 Dukungan

Jika ada pertanyaan atau masalah, silakan hubungi developer atau buka file `README-ORIGINAL.md` untuk informasi lebih lanjut.

## 📄 Lisensi

© 2026 Easy Healthy. Semua hak dilindungi.

---

**Selamat menggunakan Easy Healthy! 🏥💚**
