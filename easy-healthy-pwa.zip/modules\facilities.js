// ===================================
// Facilities Module
// ===================================

window.FacilitiesModule = {
    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('facilitiesContent');

        container.innerHTML = `
      <div class="grid grid-2 mb-3">
        <div class="card">
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Jenis Fasilitas</label>
              <select class="form-select" id="facilityTypeFilter" onchange="FacilitiesModule.filterByType(this.value)">
                <option value="">Semua</option>
                <option value="hospital">Rumah Sakit</option>
                <option value="puskesmas">Puskesmas</option>
                <option value="clinic">Klinik</option>
                <option value="pharmacy">Apotek</option>
              </select>
            </div>
          </div>
        </div>
        
        <div class="card">
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Cari Fasilitas</label>
              <input type="text" class="form-input" id="facilitySearch" placeholder="Nama atau lokasi..." onkeyup="FacilitiesModule.search(this.value)">
            </div>
          </div>
        </div>
      </div>
      
      <div id="facilitiesList"></div>
    `;

        this.loadFacilities();
    },

    facilities: [
        {
            id: 1,
            name: 'RS Umum Pusat Nasional Dr. Cipto Mangunkusumo',
            type: 'hospital',
            address: 'Jl. Diponegoro No.71, Jakarta Pusat',
            phone: '(021) 3149340',
            hours: '24 Jam',
            services: ['IGD', 'Rawat Inap', 'Rawat Jalan', 'ICU', 'Operasi'],
            distance: '2.5 km',
            lat: -6.186486,
            lng: 106.831169
        },
        {
            id: 2,
            name: 'RS Siloam Hospitals TB Simatupang',
            type: 'hospital',
            address: 'Jl. R.A. Kartini No.8, Jakarta Selatan',
            phone: '(021) 29961888',
            hours: '24 Jam',
            services: ['IGD', 'Rawat Inap', 'Rawat Jalan', 'Medical Check Up'],
            distance: '3.8 km',
            lat: -6.293371,
            lng: 106.821106
        },
        {
            id: 3,
            name: 'Puskesmas Kecamatan Menteng',
            type: 'puskesmas',
            address: 'Jl. Cikini Raya No.73, Jakarta Pusat',
            phone: '(021) 3193943',
            hours: 'Senin-Jumat 08:00-14:00',
            services: ['Poli Umum', 'KIA', 'Imunisasi', 'Laboratorium'],
            distance: '1.2 km',
            lat: -6.195157,
            lng: 106.837410
        },
        {
            id: 4,
            name: 'Puskesmas Kelurahan Tanah Abang',
            type: 'puskesmas',
            address: 'Jl. K.H. Mas Mansyur, Jakarta Pusat',
            phone: '(021) 5734567',
            hours: 'Senin-Sabtu 07:00-20:00',
            services: ['Poli Umum', 'Gigi', 'Imunisasi'],
            distance: '800 m',
            lat: -6.207968,
            lng: 106.814972
        },
        {
            id: 5,
            name: 'Klinik Pratama Sehat Sentosa',
            type: 'clinic',
            address: 'Jl. Sudirman No.123, Jakarta Selatan',
            phone: '(021) 5201234',
            hours: 'Senin-Minggu 08:00-21:00',
            services: ['Poli Umum', 'Gigi', 'Laboratorium'],
            distance: '1.5 km',
            lat: -6.225014,
            lng: 106.809250
        },
        {
            id: 6,
            name: 'Klinik Kimia Farma',
            type: 'clinic',
            address: 'Jl. Gatot Subroto, Jakarta Selatan',
            phone: '(021) 5227890',
            hours: 'Senin-Minggu 07:00-22:00',
            services: ['Poli Umum', 'Laboratorium', 'Apotek'],
            distance: '2.1 km',
            lat: -6.238270,
            lng: 106.798103
        },
        {
            id: 7,
            name: 'Apotek K-24 Sudirman',
            type: 'pharmacy',
            address: 'Jl. Jend. Sudirman Kav. 52-53, Jakarta Selatan',
            phone: '(021) 5150024',
            hours: '24 Jam',
            services: ['Obat Resep', 'Obat Bebas', 'Alat Kesehatan'],
            distance: '1.8 km',
            lat: -6.224444,
            lng: 106.808889
        },
        {
            id: 8,
            name: 'Apotek Guardian Plaza Indonesia',
            type: 'pharmacy',
            address: 'Plaza Indonesia, Jakarta Pusat',
            phone: '(021) 3108888',
            hours: 'Senin-Minggu 10:00-22:00',
            services: ['Obat Resep', 'Obat Bebas', 'Suplemen', 'Kosmetik'],
            distance: '2.3 km',
            lat: -6.193889,
            lng: 106.821667
        }
    ],

    currentFilter: '',
    currentSearch: '',

    loadFacilities() {
        const container = document.getElementById('facilitiesList');
        if (!container) return;

        let facilities = this.facilities;

        // Apply type filter
        if (this.currentFilter) {
            facilities = facilities.filter(f => f.type === this.currentFilter);
        }

        // Apply search
        if (this.currentSearch) {
            facilities = facilities.filter(f =>
                f.name.toLowerCase().includes(this.currentSearch.toLowerCase()) ||
                f.address.toLowerCase().includes(this.currentSearch.toLowerCase())
            );
        }

        if (facilities.length === 0) {
            container.innerHTML = '<p class="text-center">Tidak ada fasilitas yang ditemukan</p>';
            return;
        }

        const typeIcons = {
            hospital: 'fa-hospital',
            puskesmas: 'fa-clinic-medical',
            clinic: 'fa-briefcase-medical',
            pharmacy: 'fa-prescription-bottle-alt'
        };

        const typeLabels = {
            hospital: 'Rumah Sakit',
            puskesmas: 'Puskesmas',
            clinic: 'Klinik',
            pharmacy: 'Apotek'
        };

        container.innerHTML = facilities.map(facility => `
      <div class="card mb-3">
        <div class="card-header">
          <h3 class="card-title">
            <i class="fas ${typeIcons[facility.type]}"></i> ${facility.name}
          </h3>
          <span class="badge badge-primary">${typeLabels[facility.type]}</span>
        </div>
        <div class="card-body">
          <div class="grid grid-2">
            <div>
              <p><i class="fas fa-map-marker-alt"></i> <strong>Alamat:</strong><br>${facility.address}</p>
              <p><i class="fas fa-phone"></i> <strong>Telepon:</strong> ${facility.phone}</p>
              <p><i class="fas fa-clock"></i> <strong>Jam Operasional:</strong> ${facility.hours}</p>
              <p><i class="fas fa-route"></i> <strong>Jarak:</strong> ${facility.distance}</p>
            </div>
            <div>
              <p><strong>Layanan:</strong></p>
              <div>
                ${facility.services.map(service => `
                  <span class="badge badge-info mb-1">${service}</span>
                `).join(' ')}
              </div>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary" onclick="FacilitiesModule.showMap('${facility.id}')">
            <i class="fas fa-map"></i> Lihat Peta
          </button>
          <button class="btn btn-success" onclick="FacilitiesModule.getDirections('${facility.id}')">
            <i class="fas fa-directions"></i> Petunjuk Arah
          </button>
          <button class="btn btn-secondary" onclick="window.open('tel:${facility.phone}')">
            <i class="fas fa-phone"></i> Telepon
          </button>
        </div>
      </div>
    `).join('');
    },

    filterByType(type) {
        this.currentFilter = type;
        this.loadFacilities();
    },

    search(query) {
        this.currentSearch = query;
        this.loadFacilities();
    },

    showMap(id) {
        const facility = this.facilities.find(f => f.id == id);
        if (!facility) return;

        const mapUrl = `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.${Math.random().toString().substr(2, 6)}!2d${facility.lng}!3d${facility.lat}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zM8KwMTEnNDcuOCJTIDEwNsKwNDknMTYuMiJF!5e0!3m2!1sen!2sid!4v1234567890123!5m2!1sen!2sid`;

        const content = `
      <div style="width: 100%; height: 400px; background: var(--light-gray); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; margin-bottom: var(--spacing-md);">
        <div style="text-align: center;">
          <i class="fas fa-map-marked-alt" style="font-size: 4rem; color: var(--primary-green); margin-bottom: var(--spacing-md);"></i>
          <p>Peta akan ditampilkan di sini</p>
          <p><small>Koordinat: ${facility.lat}, ${facility.lng}</small></p>
        </div>
      </div>
      <div class="alert alert-info">
        <p><strong>${facility.name}</strong></p>
        <p>${facility.address}</p>
        <p>Jarak: ${facility.distance}</p>
      </div>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Tutup</button>
      <button class="btn btn-primary" onclick="FacilitiesModule.getDirections('${id}')">
        <i class="fas fa-directions"></i> Petunjuk Arah
      </button>
    `;

        Modal.create('Lokasi ' + facility.name, content, { footer });
    },

    getDirections(id) {
        const facility = this.facilities.find(f => f.id == id);
        if (!facility) return;

        // Open Google Maps with directions
        const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${facility.lat},${facility.lng}&destination_place_id=${facility.name}`;
        window.open(mapsUrl, '_blank');
        Utils.showAlert('Membuka Google Maps untuk petunjuk arah...', 'info');
    }
};
