// ===================================
// Registration Module
// ===================================

window.RegistrationModule = {
    selectedFacility: null,
    selectedDate: null,
    selectedTime: null,

    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('registrationContent');

        container.innerHTML = `
      <div class="grid grid-2">
        <!-- Registration Form -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Form Pendaftaran Online</h3>
          </div>
          <div class="card-body">
            <form id="registrationForm" onsubmit="RegistrationModule.submitRegistration(event)">
              <div class="form-group">
                <label class="form-label required">Nama Lengkap</label>
                <input type="text" class="form-input" name="name" id="regName" required>
              </div>
              
              <div class="form-group">
                <label class="form-label required">NIK</label>
                <input type="text" class="form-input" name="nik" pattern="[0-9]{16}" maxlength="16" required>
              </div>
              
              <div class="form-group">
                <label class="form-label required">Nomor Telepon</label>
                <input type="tel" class="form-input" name="phone" required>
              </div>
              
              <div class="form-group">
                <label class="form-label required">Jenis Fasilitas</label>
                <select class="form-select" name="facilityType" onchange="RegistrationModule.loadFacilities(this.value)" required>
                  <option value="">Pilih Jenis Fasilitas</option>
                  <option value="hospital">Rumah Sakit</option>
                  <option value="puskesmas">Puskesmas</option>
                  <option value="clinic">Klinik</option>
                </select>
              </div>
              
              <div class="form-group">
                <label class="form-label required">Pilih Fasilitas</label>
                <select class="form-select" name="facility" id="facilitySelect" required disabled>
                  <option value="">Pilih jenis fasilitas terlebih dahulu</option>
                </select>
              </div>
              
              <div class="form-group">
                <label class="form-label required">Departemen/Poli</label>
                <select class="form-select" name="department" required>
                  <option value="">Pilih Departemen</option>
                  <option value="Umum">Poli Umum</option>
                  <option value="Gigi">Poli Gigi</option>
                  <option value="Anak">Poli Anak</option>
                  <option value="Kandungan">Poli Kandungan</option>
                  <option value="Mata">Poli Mata</option>
                  <option value="THT">Poli THT</option>
                  <option value="Jantung">Poli Jantung</option>
                  <option value="Paru">Poli Paru</option>
                  <option value="Kulit">Poli Kulit</option>
                </select>
              </div>
              
              <div class="form-group">
                <label class="form-label">Pilih Dokter (Opsional)</label>
                <select class="form-select" name="doctor">
                  <option value="">Dokter yang tersedia</option>
                  <option value="Dr. Ahmad Wijaya, Sp.PD">Dr. Ahmad Wijaya, Sp.PD</option>
                  <option value="Dr. Siti Nurhaliza, Sp.A">Dr. Siti Nurhaliza, Sp.A</option>
                  <option value="Dr. Budi Santoso, Sp.OG">Dr. Budi Santoso, Sp.OG</option>
                  <option value="Dr. Linda Kusuma, Sp.M">Dr. Linda Kusuma, Sp.M</option>
                </select>
              </div>
              
              <div class="form-group">
                <label class="form-label">Keluhan</label>
                <textarea class="form-textarea" name="complaint" placeholder="Jelaskan keluhan Anda"></textarea>
              </div>
              
              <button type="button" class="btn btn-primary btn-block btn-lg" onclick="RegistrationModule.showSchedule()">
                <i class="fas fa-calendar-alt"></i> Pilih Jadwal Pemeriksaan
              </button>
            </form>
          </div>
        </div>
        
        <!-- Schedule Selection -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Pilih Tanggal & Waktu</h3>
          </div>
          <div class="card-body">
            <div class="form-group">
              <label class="form-label required">Tanggal Pemeriksaan</label>
              <input type="date" class="form-input" id="appointmentDate" onchange="RegistrationModule.selectDate(this.value)" min="${new Date().toISOString().split('T')[0]}">
            </div>
            
            <div id="timeSlots" class="mb-3">
              <p class="text-center" style="color: var(--dark-gray);">Pilih tanggal untuk melihat slot waktu yang tersedia</p>
            </div>
            
            <div id="selectedSchedule" class="hidden">
              <div class="alert alert-success">
                <h4>Jadwal Terpilih</h4>
                <p><strong>Tanggal:</strong> <span id="selectedDateDisplay">-</span></p>
                <p><strong>Waktu:</strong> <span id="selectedTimeDisplay">-</span></p>
                <p><strong>Perkiraan Pemeriksaan:</strong> <span id="estimatedTime">-</span></p>
                <p><strong>Nomor Antrian:</strong> <span id="queueNumber" class="badge badge-primary">-</span></p>
              </div>
              
              <button type="submit" form="registrationForm" class="btn btn-success btn-block btn-lg">
                <i class="fas fa-check-circle"></i> Konfirmasi Pendaftaran
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <hr class="mt-4 mb-4">
      
      <!-- Registration History -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Riwayat Pendaftaran</h3>
        </div>
        <div class="card-body">
          <div id="registrationHistory"></div>
        </div>
      </div>
    `;

        this.loadUserProfile();
        this.loadRegistrationHistory();
    },

    loadUserProfile() {
        const profile = Storage.get('userProfile');
        if (profile) {
            const nameInput = document.getElementById('regName');
            if (nameInput && profile.name) {
                nameInput.value = profile.name;
            }
        }
    },

    loadFacilities(type) {
        const select = document.getElementById('facilitySelect');

        const facilities = {
            hospital: [
                'RS Umum Pusat Nasional',
                'RS Siloam',
                'RS Mitra Keluarga',
                'RS Hermina'
            ],
            puskesmas: [
                'Puskesmas Kecamatan 1',
                'Puskesmas Kecamatan 2',
                'Puskesmas Kelurahan A'
            ],
            clinic: [
                'Klinik Pratama Sehat',
                'Klinik Kimia Farma',
                'Klinik Prodia'
            ]
        };

        if (facilities[type]) {
            select.disabled = false;
            select.innerHTML = '<option value="">Pilih Fasilitas</option>' +
                facilities[type].map(f => `<option value="${f}">${f}</option>`).join('');
        } else {
            select.disabled = true;
            select.innerHTML = '<option value="">Pilih jenis fasilitas terlebih dahulu</option>';
        }
    },

    selectDate(date) {
        this.selectedDate = date;
        this.showTimeSlots();
    },

    showTimeSlots() {
        const container = document.getElementById('timeSlots');

        const timeSlots = [
            { time: '08:00', available: true },
            { time: '09:00', available: true },
            { time: '10:00', available: false },
            { time: '11:00', available: true },
            { time: '13:00', available: true },
            { time: '14:00', available: true },
            { time: '15:00', available: false },
            { time: '16:00', available: true }
        ];

        container.innerHTML = `
      <label class="form-label">Pilih Waktu Pemeriksaan</label>
      <div class="grid grid-4">
        ${timeSlots.map(slot => `
          <button 
            type="button"
            class="btn ${slot.available ? 'btn-secondary' : 'btn-danger'} btn-sm"
            onclick="RegistrationModule.selectTime('${slot.time}')"
            ${!slot.available ? 'disabled' : ''}
          >
            ${slot.time}
            ${!slot.available ? '<br><small>Penuh</small>' : ''}
          </button>
        `).join('')}
      </div>
    `;
    },

    selectTime(time) {
        this.selectedTime = time;
        this.updateSelectedSchedule();
    },

    updateSelectedSchedule() {
        if (!this.selectedDate || !this.selectedTime) return;

        const queueNumber = Math.floor(Math.random() * 50) + 1;
        const estimatedWait = Math.floor(Math.random() * 60) + 15;

        document.getElementById('selectedDateDisplay').textContent = Utils.formatDate(this.selectedDate);
        document.getElementById('selectedTimeDisplay').textContent = this.selectedTime;
        document.getElementById('estimatedTime').textContent = `${this.selectedTime} - ${estimatedWait} menit`;
        document.getElementById('queueNumber').textContent = `A${queueNumber.toString().padStart(3, '0')}`;

        document.getElementById('selectedSchedule').classList.remove('hidden');
    },

    showSchedule() {
        const form = document.getElementById('registrationForm');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        Utils.showAlert('Silakan pilih tanggal dan waktu pemeriksaan di sebelah kanan', 'info');
        document.getElementById('appointmentDate').focus();
    },

    submitRegistration(event) {
        event.preventDefault();

        if (!this.selectedDate || !this.selectedTime) {
            Utils.showAlert('Silakan pilih tanggal dan waktu pemeriksaan terlebih dahulu', 'warning');
            return;
        }

        const form = event.target;
        const formData = new FormData(form);

        const registration = {
            id: Utils.generateId(),
            registrationNumber: 'REG' + Date.now(),
            name: formData.get('name'),
            nik: formData.get('nik'),
            phone: formData.get('phone'),
            facilityType: formData.get('facilityType'),
            facility: formData.get('facility'),
            department: formData.get('department'),
            doctor: formData.get('doctor') || 'Dokter yang tersedia',
            complaint: formData.get('complaint'),
            date: this.selectedDate,
            time: this.selectedTime,
            queueNumber: document.getElementById('queueNumber').textContent,
            status: 'Terkonfirmasi',
            createdAt: new Date().toISOString()
        };

        const registrations = Storage.get('registrations') || [];
        registrations.push(registration);
        Storage.set('registrations', registrations);

        Utils.showAlert('Pendaftaran berhasil! Nomor registrasi: ' + registration.registrationNumber, 'success');

        // Show confirmation modal
        this.showConfirmation(registration);

        // Reset form
        form.reset();
        this.selectedDate = null;
        this.selectedTime = null;
        document.getElementById('selectedSchedule').classList.add('hidden');
        document.getElementById('timeSlots').innerHTML = '<p class="text-center" style="color: var(--dark-gray);">Pilih tanggal untuk melihat slot waktu yang tersedia</p>';

        this.loadRegistrationHistory();
    },

    showConfirmation(registration) {
        const content = `
      <div class="text-center">
        <i class="fas fa-check-circle" style="font-size: 4rem; color: var(--success); margin-bottom: var(--spacing-lg);"></i>
        <h3>Pendaftaran Berhasil!</h3>
        <div class="alert alert-success text-left mt-3">
          <p><strong>Nomor Registrasi:</strong> ${registration.registrationNumber}</p>
          <p><strong>Nama:</strong> ${registration.name}</p>
          <p><strong>Fasilitas:</strong> ${registration.facility}</p>
          <p><strong>Departemen:</strong> ${registration.department}</p>
          <p><strong>Dokter:</strong> ${registration.doctor}</p>
          <p><strong>Tanggal:</strong> ${Utils.formatDate(registration.date)}</p>
          <p><strong>Waktu:</strong> ${registration.time}</p>
          <p><strong>Nomor Antrian:</strong> <span class="badge badge-primary">${registration.queueNumber}</span></p>
        </div>
        <div class="alert alert-info text-left">
          <strong>Persiapan:</strong>
          <ul>
            <li>Datang 15 menit sebelum waktu pemeriksaan</li>
            <li>Bawa kartu identitas (KTP/SIM)</li>
            <li>Bawa kartu BPJS jika ada</li>
            <li>Catat nomor registrasi Anda</li>
          </ul>
        </div>
      </div>
    `;

        const footer = `
      <button class="btn btn-primary" onclick="Modal.close(this)">Tutup</button>
    `;

        Modal.create('Konfirmasi Pendaftaran', content, { footer });
    },

    loadRegistrationHistory() {
        const container = document.getElementById('registrationHistory');
        if (!container) return;

        const registrations = Storage.get('registrations') || [];

        if (registrations.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada riwayat pendaftaran</p>';
            return;
        }

        // Sort by date descending
        registrations.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        container.innerHTML = `
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>No. Registrasi</th>
              <th>Tanggal</th>
              <th>Waktu</th>
              <th>Fasilitas</th>
              <th>Departemen</th>
              <th>Antrian</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            ${registrations.map(reg => `
              <tr>
                <td><strong>${reg.registrationNumber}</strong></td>
                <td>${Utils.formatDate(reg.date)}</td>
                <td>${reg.time}</td>
                <td>${reg.facility}</td>
                <td>${reg.department}</td>
                <td><span class="badge badge-primary">${reg.queueNumber}</span></td>
                <td><span class="badge badge-success">${reg.status}</span></td>
                <td>
                  <button class="btn btn-sm btn-secondary" onclick="RegistrationModule.viewDetails('${reg.id}')">
                    <i class="fas fa-eye"></i>
                  </button>
                  <button class="btn btn-sm btn-danger" onclick="RegistrationModule.cancelRegistration('${reg.id}')">
                    <i class="fas fa-times"></i>
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
    },

    viewDetails(id) {
        const registrations = Storage.get('registrations') || [];
        const registration = registrations.find(r => r.id === id);

        if (!registration) return;

        const content = `
      <div class="alert alert-info">
        <p><strong>Nomor Registrasi:</strong> ${registration.registrationNumber}</p>
        <p><strong>Nama:</strong> ${registration.name}</p>
        <p><strong>NIK:</strong> ${registration.nik}</p>
        <p><strong>Telepon:</strong> ${registration.phone}</p>
        <p><strong>Fasilitas:</strong> ${registration.facility}</p>
        <p><strong>Departemen:</strong> ${registration.department}</p>
        <p><strong>Dokter:</strong> ${registration.doctor}</p>
        <p><strong>Tanggal:</strong> ${Utils.formatDate(registration.date)}</p>
        <p><strong>Waktu:</strong> ${registration.time}</p>
        <p><strong>Nomor Antrian:</strong> <span class="badge badge-primary">${registration.queueNumber}</span></p>
        <p><strong>Keluhan:</strong> ${registration.complaint || '-'}</p>
        <p><strong>Status:</strong> <span class="badge badge-success">${registration.status}</span></p>
      </div>
    `;

        const footer = `
      <button class="btn btn-primary" onclick="Modal.close(this)">Tutup</button>
    `;

        Modal.create('Detail Pendaftaran', content, { footer });
    },

    cancelRegistration(id) {
        if (!Utils.confirm('Apakah Anda yakin ingin membatalkan pendaftaran ini?')) return;

        let registrations = Storage.get('registrations') || [];
        registrations = registrations.filter(r => r.id !== id);
        Storage.set('registrations', registrations);

        Utils.showAlert('Pendaftaran berhasil dibatalkan', 'success');
        this.loadRegistrationHistory();
    }
};
