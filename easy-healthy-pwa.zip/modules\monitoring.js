// ===================================
// Monitoring Module
// ===================================

window.MonitoringModule = {
    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('monitoringContent');

        container.innerHTML = `
      <div class="tabs">
        <ul class="tab-list">
          <li><button class="tab-button active" onclick="MonitoringModule.showTab('vitals')">Vital Signs</button></li>
          <li><button class="tab-button" onclick="MonitoringModule.showTab('meals')">Pola Makan</button></li>
          <li><button class="tab-button" onclick="MonitoringModule.showTab('sleep')">Pola Tidur</button></li>
          <li><button class="tab-button" onclick="MonitoringModule.showTab('activity')">Aktivitas</button></li>
        </ul>
      </div>
      
      <!-- Vitals Tab -->
      <div id="tab-vitals" class="tab-content active">
        <div class="grid grid-3">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><i class="fas fa-heartbeat"></i> Tekanan Darah</h3>
            </div>
            <div class="card-body">
              <button class="btn btn-primary btn-sm mb-2" onclick="MonitoringModule.addBloodPressure()">
                <i class="fas fa-plus"></i> Tambah Data
              </button>
              <div id="bloodPressureList"></div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><i class="fas fa-tint"></i> Gula Darah</h3>
            </div>
            <div class="card-body">
              <button class="btn btn-primary btn-sm mb-2" onclick="MonitoringModule.addBloodSugar()">
                <i class="fas fa-plus"></i> Tambah Data
              </button>
              <div id="bloodSugarList"></div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><i class="fas fa-weight"></i> Berat Badan</h3>
            </div>
            <div class="card-body">
              <button class="btn btn-primary btn-sm mb-2" onclick="MonitoringModule.addWeight()">
                <i class="fas fa-plus"></i> Tambah Data
              </button>
              <div id="weightList"></div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Meals Tab -->
      <div id="tab-meals" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Tracking Kalori & Pola Makan</h3>
          </div>
          <div class="card-body">
            <div class="grid grid-2 mb-3">
              <div class="form-group">
                <label class="form-label">Target Kalori Harian</label>
                <input type="number" class="form-input" id="calorieTarget" value="${Storage.get('calorieTarget') || 2000}" onchange="MonitoringModule.saveCalorieTarget(this.value)">
              </div>
              <div class="form-group">
                <label class="form-label">Target Diet</label>
                <select class="form-select" id="dietTarget" onchange="MonitoringModule.saveDietTarget(this.value)">
                  <option value="maintain" ${Storage.get('dietTarget') === 'maintain' ? 'selected' : ''}>Pertahankan Berat</option>
                  <option value="lose" ${Storage.get('dietTarget') === 'lose' ? 'selected' : ''}>Turunkan Berat</option>
                  <option value="gain" ${Storage.get('dietTarget') === 'gain' ? 'selected' : ''}>Naikkan Berat</option>
                </select>
              </div>
            </div>
            
            <div id="calorieProgress" class="mb-3"></div>
            
            <button class="btn btn-primary mb-3" onclick="MonitoringModule.addMeal()">
              <i class="fas fa-utensils"></i> Tambah Makanan
            </button>
            
            <div id="mealsList"></div>
          </div>
        </div>
      </div>
      
      <!-- Sleep Tab -->
      <div id="tab-sleep" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Pola Tidur</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="MonitoringModule.addSleep()">
              <i class="fas fa-bed"></i> Catat Tidur
            </button>
            <div id="sleepList"></div>
          </div>
        </div>
      </div>
      
      <!-- Activity Tab -->
      <div id="tab-activity" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Aktivitas Harian</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="MonitoringModule.addActivity()">
              <i class="fas fa-running"></i> Tambah Aktivitas
            </button>
            <div id="activityList"></div>
          </div>
        </div>
      </div>
    `;

        this.loadVitals();
        this.loadMeals();
        this.loadSleep();
        this.loadActivities();
    },

    showTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    },

    // Blood Pressure
    addBloodPressure() {
        const content = `
      <form id="bpForm">
        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label required">Sistolik</label>
            <input type="number" class="form-input" name="systolic" required>
          </div>
          <div class="form-group">
            <label class="form-label required">Diastolik</label>
            <input type="number" class="form-input" name="diastolic" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal & Waktu</label>
          <input type="datetime-local" class="form-input" name="datetime" value="${new Date().toISOString().slice(0, 16)}" required>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="MonitoringModule.saveBloodPressure()">Simpan</button>
    `;

        Modal.create('Tambah Tekanan Darah', content, { footer });
    },

    saveBloodPressure() {
        const form = document.getElementById('bpForm');
        const formData = new FormData(form);
        const data = Storage.get('bloodPressure') || [];

        data.push({
            id: Utils.generateId(),
            systolic: formData.get('systolic'),
            diastolic: formData.get('diastolic'),
            datetime: formData.get('datetime')
        });

        Storage.set('bloodPressure', data);
        Utils.showAlert('Data tekanan darah berhasil disimpan!', 'success');
        Modal.close(form);
        this.loadVitals();
    },

    // Blood Sugar
    addBloodSugar() {
        const content = `
      <form id="bsForm">
        <div class="form-group">
          <label class="form-label required">Kadar Gula (mg/dL)</label>
          <input type="number" class="form-input" name="level" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Konteks</label>
          <select class="form-select" name="context" required>
            <option value="fasting">Puasa</option>
            <option value="before_meal">Sebelum Makan</option>
            <option value="after_meal">Setelah Makan</option>
            <option value="random">Random</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal & Waktu</label>
          <input type="datetime-local" class="form-input" name="datetime" value="${new Date().toISOString().slice(0, 16)}" required>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="MonitoringModule.saveBloodSugar()">Simpan</button>
    `;

        Modal.create('Tambah Gula Darah', content, { footer });
    },

    saveBloodSugar() {
        const form = document.getElementById('bsForm');
        const formData = new FormData(form);
        const data = Storage.get('bloodSugar') || [];

        data.push({
            id: Utils.generateId(),
            level: formData.get('level'),
            context: formData.get('context'),
            datetime: formData.get('datetime')
        });

        Storage.set('bloodSugar', data);
        Utils.showAlert('Data gula darah berhasil disimpan!', 'success');
        Modal.close(form);
        this.loadVitals();
    },

    // Weight
    addWeight() {
        const content = `
      <form id="weightForm">
        <div class="form-group">
          <label class="form-label required">Berat Badan (kg)</label>
          <input type="number" step="0.1" class="form-input" name="weight" required>
        </div>
        <div class="form-group">
          <label class="form-label">Tinggi Badan (cm)</label>
          <input type="number" class="form-input" name="height">
          <small class="form-help">Untuk menghitung BMI</small>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal</label>
          <input type="date" class="form-input" name="date" value="${new Date().toISOString().split('T')[0]}" required>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="MonitoringModule.saveWeight()">Simpan</button>
    `;

        Modal.create('Tambah Berat Badan', content, { footer });
    },

    saveWeight() {
        const form = document.getElementById('weightForm');
        const formData = new FormData(form);
        const data = Storage.get('weight') || [];

        const weight = parseFloat(formData.get('weight'));
        const height = parseFloat(formData.get('height'));
        let bmi = null;

        if (height) {
            bmi = (weight / ((height / 100) ** 2)).toFixed(1);
        }

        data.push({
            id: Utils.generateId(),
            weight: weight,
            height: height,
            bmi: bmi,
            date: formData.get('date')
        });

        Storage.set('weight', data);
        Utils.showAlert('Data berat badan berhasil disimpan!', 'success');
        Modal.close(form);
        this.loadVitals();
    },

    loadVitals() {
        // Blood Pressure
        const bpContainer = document.getElementById('bloodPressureList');
        if (bpContainer) {
            const bpData = Storage.get('bloodPressure') || [];
            if (bpData.length === 0) {
                bpContainer.innerHTML = '<p class="text-center">Belum ada data</p>';
            } else {
                bpContainer.innerHTML = bpData.slice(-5).reverse().map(item => `
          <div class="mb-2 p-2" style="background: var(--off-white); border-radius: var(--radius-sm);">
            <strong>${item.systolic}/${item.diastolic}</strong> mmHg<br>
            <small>${Utils.formatDateTime(item.datetime)}</small>
          </div>
        `).join('');
            }
        }

        // Blood Sugar
        const bsContainer = document.getElementById('bloodSugarList');
        if (bsContainer) {
            const bsData = Storage.get('bloodSugar') || [];
            if (bsData.length === 0) {
                bsContainer.innerHTML = '<p class="text-center">Belum ada data</p>';
            } else {
                bsContainer.innerHTML = bsData.slice(-5).reverse().map(item => `
          <div class="mb-2 p-2" style="background: var(--off-white); border-radius: var(--radius-sm);">
            <strong>${item.level}</strong> mg/dL<br>
            <small>${item.context} - ${Utils.formatDateTime(item.datetime)}</small>
          </div>
        `).join('');
            }
        }

        // Weight
        const weightContainer = document.getElementById('weightList');
        if (weightContainer) {
            const weightData = Storage.get('weight') || [];
            if (weightData.length === 0) {
                weightContainer.innerHTML = '<p class="text-center">Belum ada data</p>';
            } else {
                weightContainer.innerHTML = weightData.slice(-5).reverse().map(item => `
          <div class="mb-2 p-2" style="background: var(--off-white); border-radius: var(--radius-sm);">
            <strong>${item.weight}</strong> kg${item.bmi ? ` (BMI: ${item.bmi})` : ''}<br>
            <small>${Utils.formatDate(item.date)}</small>
          </div>
        `).join('');
            }
        }
    },

    // Meals
    saveCalorieTarget(value) {
        Storage.set('calorieTarget', value);
        this.loadMeals();
    },

    saveDietTarget(value) {
        Storage.set('dietTarget', value);
    },

    addMeal() {
        const content = `
      <form id="mealForm">
        <div class="form-group">
          <label class="form-label required">Waktu Makan</label>
          <select class="form-select" name="mealType" required>
            <option value="breakfast">Sarapan</option>
            <option value="lunch">Makan Siang</option>
            <option value="dinner">Makan Malam</option>
            <option value="snack">Snack</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">Nama Makanan</label>
          <input type="text" class="form-input" name="food" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Kalori</label>
          <input type="number" class="form-input" name="calories" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal</label>
          <input type="date" class="form-input" name="date" value="${new Date().toISOString().split('T')[0]}" required>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="MonitoringModule.saveMeal()">Simpan</button>
    `;

        Modal.create('Tambah Makanan', content, { footer });
    },

    saveMeal() {
        const form = document.getElementById('mealForm');
        const formData = new FormData(form);
        const meals = Storage.get('meals') || [];

        meals.push({
            id: Utils.generateId(),
            mealType: formData.get('mealType'),
            food: formData.get('food'),
            calories: parseInt(formData.get('calories')),
            date: formData.get('date')
        });

        Storage.set('meals', meals);
        Utils.showAlert('Makanan berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadMeals();
    },

    loadMeals() {
        const container = document.getElementById('mealsList');
        const progressContainer = document.getElementById('calorieProgress');

        if (!container) return;

        const meals = Storage.get('meals') || [];
        const target = parseInt(Storage.get('calorieTarget') || 2000);
        const today = new Date().toISOString().split('T')[0];
        const todayMeals = meals.filter(m => m.date === today);
        const totalCalories = todayMeals.reduce((sum, m) => sum + m.calories, 0);
        const percentage = Math.min((totalCalories / target) * 100, 100);

        if (progressContainer) {
            progressContainer.innerHTML = `
        <h4>Kalori Hari Ini</h4>
        <div class="progress">
          <div class="progress-bar" style="width: ${percentage}%">
            ${totalCalories} / ${target} kal
          </div>
        </div>
      `;
        }

        if (todayMeals.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada makanan hari ini</p>';
            return;
        }

        const mealTypes = {
            breakfast: 'Sarapan',
            lunch: 'Makan Siang',
            dinner: 'Makan Malam',
            snack: 'Snack'
        };

        container.innerHTML = todayMeals.map(meal => `
      <div class="card mb-2">
        <div class="card-body">
          <h4>${mealTypes[meal.mealType]}</h4>
          <p>${meal.food} - <strong>${meal.calories} kal</strong></p>
        </div>
      </div>
    `).join('');
    },

    // Sleep
    addSleep() {
        const content = `
      <form id="sleepForm">
        <div class="form-group">
          <label class="form-label required">Durasi Tidur (jam)</label>
          <input type="number" step="0.5" class="form-input" name="duration" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Kualitas</label>
          <select class="form-select" name="quality" required>
            <option value="poor">Buruk</option>
            <option value="fair">Cukup</option>
            <option value="good">Baik</option>
            <option value="excellent">Sangat Baik</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Catatan</label>
          <textarea class="form-textarea" name="notes"></textarea>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal</label>
          <input type="date" class="form-input" name="date" value="${new Date().toISOString().split('T')[0]}" required>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="MonitoringModule.saveSleep()">Simpan</button>
    `;

        Modal.create('Catat Tidur', content, { footer });
    },

    saveSleep() {
        const form = document.getElementById('sleepForm');
        const formData = new FormData(form);
        const sleep = Storage.get('sleep') || [];

        sleep.push({
            id: Utils.generateId(),
            duration: formData.get('duration'),
            quality: formData.get('quality'),
            notes: formData.get('notes'),
            date: formData.get('date')
        });

        Storage.set('sleep', sleep);
        Utils.showAlert('Data tidur berhasil disimpan!', 'success');
        Modal.close(form);
        this.loadSleep();
    },

    loadSleep() {
        const container = document.getElementById('sleepList');
        if (!container) return;

        const sleep = Storage.get('sleep') || [];

        if (sleep.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada data tidur</p>';
            return;
        }

        const qualityLabels = {
            poor: 'Buruk',
            fair: 'Cukup',
            good: 'Baik',
            excellent: 'Sangat Baik'
        };

        container.innerHTML = sleep.slice(-7).reverse().map(item => `
      <div class="card mb-2">
        <div class="card-body">
          <h4>${Utils.formatDate(item.date)}</h4>
          <p><strong>Durasi:</strong> ${item.duration} jam</p>
          <p><strong>Kualitas:</strong> ${qualityLabels[item.quality]}</p>
          ${item.notes ? `<p><strong>Catatan:</strong> ${item.notes}</p>` : ''}
        </div>
      </div>
    `).join('');
    },

    // Activity
    addActivity() {
        const content = `
      <form id="activityForm">
        <div class="form-group">
          <label class="form-label required">Jenis Aktivitas</label>
          <select class="form-select" name="type" required>
            <option value="walking">Berjalan</option>
            <option value="running">Lari</option>
            <option value="cycling">Bersepeda</option>
            <option value="swimming">Berenang</option>
            <option value="gym">Gym</option>
            <option value="yoga">Yoga</option>
            <option value="other">Lainnya</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">Durasi (menit)</label>
          <input type="number" class="form-input" name="duration" required>
        </div>
        <div class="form-group">
          <label class="form-label">Kalori Terbakar</label>
          <input type="number" class="form-input" name="calories">
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal</label>
          <input type="date" class="form-input" name="date" value="${new Date().toISOString().split('T')[0]}" required>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="MonitoringModule.saveActivity()">Simpan</button>
    `;

        Modal.create('Tambah Aktivitas', content, { footer });
    },

    saveActivity() {
        const form = document.getElementById('activityForm');
        const formData = new FormData(form);
        const activities = Storage.get('activities') || [];

        activities.push({
            id: Utils.generateId(),
            type: formData.get('type'),
            duration: formData.get('duration'),
            calories: formData.get('calories'),
            date: formData.get('date')
        });

        Storage.set('activities', activities);
        Utils.showAlert('Aktivitas berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadActivities();
    },

    loadActivities() {
        const container = document.getElementById('activityList');
        if (!container) return;

        const activities = Storage.get('activities') || [];

        if (activities.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada aktivitas</p>';
            return;
        }

        const activityLabels = {
            walking: 'Berjalan',
            running: 'Lari',
            cycling: 'Bersepeda',
            swimming: 'Berenang',
            gym: 'Gym',
            yoga: 'Yoga',
            other: 'Lainnya'
        };

        container.innerHTML = activities.slice(-7).reverse().map(item => `
      <div class="card mb-2">
        <div class="card-body">
          <h4>${activityLabels[item.type]} - ${Utils.formatDate(item.date)}</h4>
          <p><strong>Durasi:</strong> ${item.duration} menit</p>
          ${item.calories ? `<p><strong>Kalori:</strong> ${item.calories} kal</p>` : ''}
        </div>
      </div>
    `).join('');
    }
};
