// ===================================
// Records Module
// ===================================

window.RecordsModule = {
    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('recordsContent');

        container.innerHTML = `
      <div class="tabs">
        <ul class="tab-list">
          <li><button class="tab-button active" onclick="RecordsModule.showTab('lab')">Hasil Lab</button></li>
          <li><button class="tab-button" onclick="RecordsModule.showTab('prescriptions')">Resep Obat</button></li>
          <li><button class="tab-button" onclick="RecordsModule.showTab('referrals')">Surat Rujukan</button></li>
          <li><button class="tab-button" onclick="RecordsModule.showTab('outpatient')">Rawat Jalan</button></li>
        </ul>
      </div>
      
      <!-- Lab Results Tab -->
      <div id="tab-lab" class="tab-content active">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Hasil Laboratorium</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RecordsModule.addLabResult()">
              <i class="fas fa-upload"></i> Upload Hasil Lab
            </button>
            <div id="labResultsList"></div>
          </div>
        </div>
      </div>
      
      <!-- Prescriptions Tab -->
      <div id="tab-prescriptions" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Resep Obat</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RecordsModule.addPrescription()">
              <i class="fas fa-upload"></i> Upload Resep
            </button>
            <div id="prescriptionsList"></div>
          </div>
        </div>
      </div>
      
      <!-- Referrals Tab -->
      <div id="tab-referrals" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Surat Rujukan</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RecordsModule.addReferral()">
              <i class="fas fa-upload"></i> Upload Surat Rujukan
            </button>
            <div id="referralsList"></div>
          </div>
        </div>
      </div>
      
      <!-- Outpatient Tab -->
      <div id="tab-outpatient" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Riwayat Rawat Jalan</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RecordsModule.addOutpatient()">
              <i class="fas fa-plus"></i> Tambah Riwayat
            </button>
            <div id="outpatientList"></div>
          </div>
        </div>
      </div>
    `;

        this.loadLabResults();
        this.loadPrescriptions();
        this.loadReferrals();
        this.loadOutpatient();
    },

    showTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    },

    // Lab Results
    addLabResult() {
        const content = `
      <form id="labForm">
        <div class="form-group">
          <label class="form-label required">Jenis Pemeriksaan</label>
          <input type="text" class="form-input" name="testType" placeholder="Contoh: Darah Lengkap, Urine" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal Pemeriksaan</label>
          <input type="date" class="form-input" name="date" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Laboratorium</label>
          <input type="text" class="form-input" name="lab" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Upload File</label>
          <input type="file" class="form-input" name="file" accept=".pdf,.jpg,.jpeg,.png" required>
          <small class="form-help">Format: PDF, JPG, PNG (Max 5MB)</small>
        </div>
        <div class="form-group">
          <label class="form-label">Catatan</label>
          <textarea class="form-textarea" name="notes"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RecordsModule.saveLabResult()">Simpan</button>
    `;

        Modal.create('Upload Hasil Lab', content, { footer });
    },

    saveLabResult() {
        const form = document.getElementById('labForm');
        const formData = new FormData(form);
        const labResults = Storage.get('labResults') || [];

        labResults.push({
            id: Utils.generateId(),
            testType: formData.get('testType'),
            date: formData.get('date'),
            lab: formData.get('lab'),
            fileName: formData.get('file').name,
            notes: formData.get('notes'),
            uploadDate: new Date().toISOString()
        });

        Storage.set('labResults', labResults);
        Utils.showAlert('Hasil lab berhasil diupload!', 'success');
        Modal.close(form);
        this.loadLabResults();
    },

    loadLabResults() {
        const container = document.getElementById('labResultsList');
        if (!container) return;

        const labResults = Storage.get('labResults') || [];

        if (labResults.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada hasil lab</p>';
            return;
        }

        container.innerHTML = `
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>Jenis Pemeriksaan</th>
              <th>Tanggal</th>
              <th>Laboratorium</th>
              <th>File</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            ${labResults.map(result => `
              <tr>
                <td><strong>${result.testType}</strong></td>
                <td>${Utils.formatDate(result.date)}</td>
                <td>${result.lab}</td>
                <td><i class="fas fa-file-pdf"></i> ${result.fileName}</td>
                <td>
                  <button class="btn btn-sm btn-primary" onclick="RecordsModule.viewLabResult('${result.id}')">
                    <i class="fas fa-eye"></i>
                  </button>
                  <button class="btn btn-sm btn-danger" onclick="RecordsModule.deleteLabResult('${result.id}')">
                    <i class="fas fa-trash"></i>
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
    },

    viewLabResult(id) {
        const labResults = Storage.get('labResults') || [];
        const result = labResults.find(r => r.id === id);

        if (!result) return;

        const content = `
      <div class="alert alert-info">
        <p><strong>Jenis Pemeriksaan:</strong> ${result.testType}</p>
        <p><strong>Tanggal:</strong> ${Utils.formatDate(result.date)}</p>
        <p><strong>Laboratorium:</strong> ${result.lab}</p>
        <p><strong>File:</strong> ${result.fileName}</p>
        ${result.notes ? `<p><strong>Catatan:</strong> ${result.notes}</p>` : ''}
        <p><strong>Diupload:</strong> ${Utils.formatDateTime(result.uploadDate)}</p>
      </div>
    `;

        const footer = `
      <button class="btn btn-primary" onclick="Modal.close(this)">Tutup</button>
    `;

        Modal.create('Detail Hasil Lab', content, { footer });
    },

    deleteLabResult(id) {
        if (!Utils.confirm('Hapus hasil lab ini?')) return;

        let labResults = Storage.get('labResults') || [];
        labResults = labResults.filter(r => r.id !== id);
        Storage.set('labResults', labResults);
        Utils.showAlert('Hasil lab berhasil dihapus', 'success');
        this.loadLabResults();
    },

    // Prescriptions
    addPrescription() {
        const content = `
      <form id="prescriptionForm">
        <div class="form-group">
          <label class="form-label required">Tanggal Resep</label>
          <input type="date" class="form-input" name="date" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Dokter</label>
          <input type="text" class="form-input" name="doctor" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Rumah Sakit/Klinik</label>
          <input type="text" class="form-input" name="facility" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Upload File Resep</label>
          <input type="file" class="form-input" name="file" accept=".pdf,.jpg,.jpeg,.png" required>
        </div>
        <div class="form-group">
          <label class="form-label">Daftar Obat</label>
          <textarea class="form-textarea" name="medications" placeholder="Tuliskan daftar obat yang diresepkan"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RecordsModule.savePrescription()">Simpan</button>
    `;

        Modal.create('Upload Resep Obat', content, { footer });
    },

    savePrescription() {
        const form = document.getElementById('prescriptionForm');
        const formData = new FormData(form);
        const prescriptions = Storage.get('prescriptions') || [];

        prescriptions.push({
            id: Utils.generateId(),
            date: formData.get('date'),
            doctor: formData.get('doctor'),
            facility: formData.get('facility'),
            fileName: formData.get('file').name,
            medications: formData.get('medications'),
            uploadDate: new Date().toISOString()
        });

        Storage.set('prescriptions', prescriptions);
        Utils.showAlert('Resep berhasil diupload!', 'success');
        Modal.close(form);
        this.loadPrescriptions();
    },

    loadPrescriptions() {
        const container = document.getElementById('prescriptionsList');
        if (!container) return;

        const prescriptions = Storage.get('prescriptions') || [];

        if (prescriptions.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada resep obat</p>';
            return;
        }

        container.innerHTML = prescriptions.map(prescription => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-prescription"></i> Resep ${Utils.formatDate(prescription.date)}</h4>
          <p><strong>Dokter:</strong> ${prescription.doctor}</p>
          <p><strong>Fasilitas:</strong> ${prescription.facility}</p>
          <p><strong>File:</strong> ${prescription.fileName}</p>
          ${prescription.medications ? `<p><strong>Obat:</strong> ${prescription.medications}</p>` : ''}
        </div>
        <div class="card-footer">
          <button class="btn btn-sm btn-danger" onclick="RecordsModule.deletePrescription('${prescription.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deletePrescription(id) {
        if (!Utils.confirm('Hapus resep ini?')) return;

        let prescriptions = Storage.get('prescriptions') || [];
        prescriptions = prescriptions.filter(p => p.id !== id);
        Storage.set('prescriptions', prescriptions);
        Utils.showAlert('Resep berhasil dihapus', 'success');
        this.loadPrescriptions();
    },

    // Referrals
    addReferral() {
        const content = `
      <form id="referralForm">
        <div class="form-group">
          <label class="form-label required">Tanggal Rujukan</label>
          <input type="date" class="form-input" name="date" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Dari (Dokter/Fasilitas)</label>
          <input type="text" class="form-input" name="from" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Ke (Fasilitas Tujuan)</label>
          <input type="text" class="form-input" name="to" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Tujuan Rujukan</label>
          <input type="text" class="form-input" name="purpose" placeholder="Contoh: Konsultasi Spesialis Jantung" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Upload File</label>
          <input type="file" class="form-input" name="file" accept=".pdf,.jpg,.jpeg,.png" required>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RecordsModule.saveReferral()">Simpan</button>
    `;

        Modal.create('Upload Surat Rujukan', content, { footer });
    },

    saveReferral() {
        const form = document.getElementById('referralForm');
        const formData = new FormData(form);
        const referrals = Storage.get('referrals') || [];

        referrals.push({
            id: Utils.generateId(),
            date: formData.get('date'),
            from: formData.get('from'),
            to: formData.get('to'),
            purpose: formData.get('purpose'),
            fileName: formData.get('file').name,
            uploadDate: new Date().toISOString()
        });

        Storage.set('referrals', referrals);
        Utils.showAlert('Surat rujukan berhasil diupload!', 'success');
        Modal.close(form);
        this.loadReferrals();
    },

    loadReferrals() {
        const container = document.getElementById('referralsList');
        if (!container) return;

        const referrals = Storage.get('referrals') || [];

        if (referrals.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada surat rujukan</p>';
            return;
        }

        container.innerHTML = referrals.map(referral => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-file-medical"></i> ${referral.purpose}</h4>
          <p><strong>Tanggal:</strong> ${Utils.formatDate(referral.date)}</p>
          <p><strong>Dari:</strong> ${referral.from}</p>
          <p><strong>Ke:</strong> ${referral.to}</p>
          <p><strong>File:</strong> ${referral.fileName}</p>
        </div>
        <div class="card-footer">
          <button class="btn btn-sm btn-danger" onclick="RecordsModule.deleteReferral('${referral.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deleteReferral(id) {
        if (!Utils.confirm('Hapus surat rujukan ini?')) return;

        let referrals = Storage.get('referrals') || [];
        referrals = referrals.filter(r => r.id !== id);
        Storage.set('referrals', referrals);
        Utils.showAlert('Surat rujukan berhasil dihapus', 'success');
        this.loadReferrals();
    },

    // Outpatient
    addOutpatient() {
        const content = `
      <form id="outpatientForm">
        <div class="form-group">
          <label class="form-label required">Tanggal Kunjungan</label>
          <input type="date" class="form-input" name="date" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Fasilitas</label>
          <input type="text" class="form-input" name="facility" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Dokter</label>
          <input type="text" class="form-input" name="doctor" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Diagnosis</label>
          <input type="text" class="form-input" name="diagnosis" required>
        </div>
        <div class="form-group">
          <label class="form-label">Tindakan/Pengobatan</label>
          <textarea class="form-textarea" name="treatment"></textarea>
        </div>
        <div class="form-group">
          <label class="form-label">Catatan Dokter</label>
          <textarea class="form-textarea" name="notes"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RecordsModule.saveOutpatient()">Simpan</button>
    `;

        Modal.create('Tambah Riwayat Rawat Jalan', content, { footer });
    },

    saveOutpatient() {
        const form = document.getElementById('outpatientForm');
        const formData = new FormData(form);
        const outpatient = Storage.get('outpatient') || [];

        outpatient.push({
            id: Utils.generateId(),
            date: formData.get('date'),
            facility: formData.get('facility'),
            doctor: formData.get('doctor'),
            diagnosis: formData.get('diagnosis'),
            treatment: formData.get('treatment'),
            notes: formData.get('notes')
        });

        Storage.set('outpatient', outpatient);
        Utils.showAlert('Riwayat rawat jalan berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadOutpatient();
    },

    loadOutpatient() {
        const container = document.getElementById('outpatientList');
        if (!container) return;

        const outpatient = Storage.get('outpatient') || [];

        if (outpatient.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada riwayat rawat jalan</p>';
            return;
        }

        container.innerHTML = outpatient.map(visit => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-hospital-user"></i> ${Utils.formatDate(visit.date)}</h4>
          <p><strong>Fasilitas:</strong> ${visit.facility}</p>
          <p><strong>Dokter:</strong> ${visit.doctor}</p>
          <p><strong>Diagnosis:</strong> ${visit.diagnosis}</p>
          ${visit.treatment ? `<p><strong>Pengobatan:</strong> ${visit.treatment}</p>` : ''}
          ${visit.notes ? `<p><strong>Catatan:</strong> ${visit.notes}</p>` : ''}
        </div>
        <div class="card-footer">
          <button class="btn btn-sm btn-danger" onclick="RecordsModule.deleteOutpatient('${visit.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deleteOutpatient(id) {
        if (!Utils.confirm('Hapus riwayat ini?')) return;

        let outpatient = Storage.get('outpatient') || [];
        outpatient = outpatient.filter(o => o.id !== id);
        Storage.set('outpatient', outpatient);
        Utils.showAlert('Riwayat berhasil dihapus', 'success');
        this.loadOutpatient();
    }
};
