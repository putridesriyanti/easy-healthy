// ===================================
// Reminders Module
// ===================================

window.RemindersModule = {
    init() {
        this.render();
        this.checkReminders();
    },

    render() {
        const container = document.getElementById('remindersContent');

        container.innerHTML = `
      <div class="tabs">
        <ul class="tab-list">
          <li><button class="tab-button active" onclick="RemindersModule.showTab('medication')">Obat</button></li>
          <li><button class="tab-button" onclick="RemindersModule.showTab('checkup')">Kontrol</button></li>
          <li><button class="tab-button" onclick="RemindersModule.showTab('immunization')">Imunisasi</button></li>
          <li><button class="tab-button" onclick="RemindersModule.showTab('routine')">Pemeriksaan Rutin</button></li>
        </ul>
      </div>
      
      <!-- Medication Tab -->
      <div id="tab-medication" class="tab-content active">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Pengingat Minum Obat</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RemindersModule.addMedication()">
              <i class="fas fa-pills"></i> Tambah Pengingat Obat
            </button>
            <div id="medicationList"></div>
          </div>
        </div>
      </div>
      
      <!-- Checkup Tab -->
      <div id="tab-checkup" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Jadwal Kontrol</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RemindersModule.addCheckup()">
              <i class="fas fa-calendar-check"></i> Tambah Jadwal Kontrol
            </button>
            <div id="checkupList"></div>
          </div>
        </div>
      </div>
      
      <!-- Immunization Tab -->
      <div id="tab-immunization" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Jadwal Imunisasi</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RemindersModule.addImmunization()">
              <i class="fas fa-syringe"></i> Tambah Jadwal Imunisasi
            </button>
            <div id="immunizationList"></div>
          </div>
        </div>
      </div>
      
      <!-- Routine Tab -->
      <div id="tab-routine" class="tab-content">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Pemeriksaan Rutin</h3>
          </div>
          <div class="card-body">
            <button class="btn btn-primary mb-3" onclick="RemindersModule.addRoutine()">
              <i class="fas fa-stethoscope"></i> Tambah Pemeriksaan Rutin
            </button>
            <div id="routineList"></div>
          </div>
        </div>
      </div>
    `;

        this.loadMedications();
        this.loadCheckups();
        this.loadImmunizations();
        this.loadRoutines();
    },

    showTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    },

    // Medication
    addMedication() {
        const content = `
      <form id="medicationForm">
        <div class="form-group">
          <label class="form-label required">Nama Obat</label>
          <input type="text" class="form-input" name="name" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Dosis</label>
          <input type="text" class="form-input" name="dosage" placeholder="Contoh: 500mg" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Frekuensi</label>
          <select class="form-select" name="frequency" required>
            <option value="1">1x sehari</option>
            <option value="2">2x sehari</option>
            <option value="3">3x sehari</option>
            <option value="4">4x sehari</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">Waktu Minum (pisahkan dengan koma)</label>
          <input type="text" class="form-input" name="times" placeholder="Contoh: 08:00, 14:00, 20:00" required>
          <small class="form-help">Format: HH:MM, pisahkan dengan koma</small>
        </div>
        <div class="form-group">
          <label class="form-label required">Mulai Tanggal</label>
          <input type="date" class="form-input" name="startDate" value="${new Date().toISOString().split('T')[0]}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Sampai Tanggal</label>
          <input type="date" class="form-input" name="endDate">
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RemindersModule.saveMedication()">Simpan</button>
    `;

        Modal.create('Tambah Pengingat Obat', content, { footer });
    },

    saveMedication() {
        const form = document.getElementById('medicationForm');
        const formData = new FormData(form);
        const medications = Storage.get('medications') || [];

        medications.push({
            id: Utils.generateId(),
            name: formData.get('name'),
            dosage: formData.get('dosage'),
            frequency: formData.get('frequency'),
            times: formData.get('times').split(',').map(t => t.trim()),
            startDate: formData.get('startDate'),
            endDate: formData.get('endDate'),
            active: true
        });

        Storage.set('medications', medications);
        Utils.showAlert('Pengingat obat berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadMedications();
    },

    loadMedications() {
        const container = document.getElementById('medicationList');
        if (!container) return;

        const medications = Storage.get('medications') || [];
        const activeMeds = medications.filter(m => m.active);

        if (activeMeds.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada pengingat obat</p>';
            return;
        }

        container.innerHTML = activeMeds.map(med => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-pills"></i> ${med.name}</h4>
          <p><strong>Dosis:</strong> ${med.dosage}</p>
          <p><strong>Frekuensi:</strong> ${med.frequency}x sehari</p>
          <p><strong>Waktu:</strong> ${med.times.join(', ')}</p>
          <p><strong>Periode:</strong> ${Utils.formatDate(med.startDate)} ${med.endDate ? '- ' + Utils.formatDate(med.endDate) : '(Berlanjut)'}</p>
          <span class="badge badge-success">Aktif</span>
        </div>
        <div class="card-footer">
          <button class="btn btn-sm btn-warning" onclick="RemindersModule.toggleMedication('${med.id}')">
            <i class="fas fa-pause"></i> Nonaktifkan
          </button>
          <button class="btn btn-sm btn-danger" onclick="RemindersModule.deleteMedication('${med.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    toggleMedication(id) {
        const medications = Storage.get('medications') || [];
        const med = medications.find(m => m.id === id);
        if (med) {
            med.active = !med.active;
            Storage.set('medications', medications);
            this.loadMedications();
        }
    },

    deleteMedication(id) {
        if (!Utils.confirm('Hapus pengingat obat ini?')) return;

        let medications = Storage.get('medications') || [];
        medications = medications.filter(m => m.id !== id);
        Storage.set('medications', medications);
        Utils.showAlert('Pengingat obat berhasil dihapus', 'success');
        this.loadMedications();
    },

    // Checkup
    addCheckup() {
        const content = `
      <form id="checkupForm">
        <div class="form-group">
          <label class="form-label required">Jenis Kontrol</label>
          <input type="text" class="form-input" name="type" placeholder="Contoh: Kontrol Diabetes" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal</label>
          <input type="date" class="form-input" name="date" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Waktu</label>
          <input type="time" class="form-input" name="time" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Dokter</label>
          <input type="text" class="form-input" name="doctor" required>
        </div>
        <div class="form-group">
          <label class="form-label">Lokasi</label>
          <input type="text" class="form-input" name="location" placeholder="Nama RS/Klinik">
        </div>
        <div class="form-group">
          <label class="form-label">Catatan</label>
          <textarea class="form-textarea" name="notes"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RemindersModule.saveCheckup()">Simpan</button>
    `;

        Modal.create('Tambah Jadwal Kontrol', content, { footer });
    },

    saveCheckup() {
        const form = document.getElementById('checkupForm');
        const formData = new FormData(form);
        const checkups = Storage.get('checkups') || [];

        checkups.push({
            id: Utils.generateId(),
            type: formData.get('type'),
            date: formData.get('date'),
            time: formData.get('time'),
            doctor: formData.get('doctor'),
            location: formData.get('location'),
            notes: formData.get('notes'),
            completed: false
        });

        Storage.set('checkups', checkups);
        Utils.showAlert('Jadwal kontrol berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadCheckups();
    },

    loadCheckups() {
        const container = document.getElementById('checkupList');
        if (!container) return;

        const checkups = Storage.get('checkups') || [];
        const upcoming = checkups.filter(c => !c.completed);

        if (upcoming.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada jadwal kontrol</p>';
            return;
        }

        container.innerHTML = upcoming.map(checkup => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-user-md"></i> ${checkup.type}</h4>
          <p><strong>Tanggal:</strong> ${Utils.formatDate(checkup.date)} ${checkup.time}</p>
          <p><strong>Dokter:</strong> ${checkup.doctor}</p>
          ${checkup.location ? `<p><strong>Lokasi:</strong> ${checkup.location}</p>` : ''}
          ${checkup.notes ? `<p><strong>Catatan:</strong> ${checkup.notes}</p>` : ''}
        </div>
        <div class="card-footer">
          <button class="btn btn-sm btn-success" onclick="RemindersModule.completeCheckup('${checkup.id}')">
            <i class="fas fa-check"></i> Selesai
          </button>
          <button class="btn btn-sm btn-danger" onclick="RemindersModule.deleteCheckup('${checkup.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    completeCheckup(id) {
        const checkups = Storage.get('checkups') || [];
        const checkup = checkups.find(c => c.id === id);
        if (checkup) {
            checkup.completed = true;
            Storage.set('checkups', checkups);
            Utils.showAlert('Jadwal kontrol ditandai selesai', 'success');
            this.loadCheckups();
        }
    },

    deleteCheckup(id) {
        if (!Utils.confirm('Hapus jadwal kontrol ini?')) return;

        let checkups = Storage.get('checkups') || [];
        checkups = checkups.filter(c => c.id !== id);
        Storage.set('checkups', checkups);
        Utils.showAlert('Jadwal kontrol berhasil dihapus', 'success');
        this.loadCheckups();
    },

    // Immunization
    addImmunization() {
        const content = `
      <form id="immunizationForm">
        <div class="form-group">
          <label class="form-label required">Nama Vaksin</label>
          <select class="form-select" name="vaccine" required>
            <option value="">Pilih Vaksin</option>
            <optgroup label="Bayi (0-12 bulan)">
              <option value="BCG">BCG</option>
              <option value="Hepatitis B">Hepatitis B</option>
              <option value="Polio">Polio</option>
              <option value="DPT">DPT</option>
              <option value="Hib">Hib</option>
              <option value="PCV">PCV</option>
              <option value="Rotavirus">Rotavirus</option>
              <option value="Campak">Campak</option>
            </optgroup>
            <optgroup label="Balita (1-5 tahun)">
              <option value="MMR">MMR</option>
              <option value="Varicella">Varicella</option>
              <option value="Hepatitis A">Hepatitis A</option>
            </optgroup>
            <optgroup label="Anak (6-18 tahun)">
              <option value="Td/Tdap">Td/Tdap</option>
              <option value="HPV">HPV</option>
              <option value="Influenza">Influenza</option>
            </optgroup>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">Nama Anak</label>
          <input type="text" class="form-input" name="childName" required>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal Jadwal</label>
          <input type="date" class="form-input" name="dueDate" required>
        </div>
        <div class="form-group">
          <label class="form-label">Lokasi</label>
          <input type="text" class="form-input" name="location" placeholder="Puskesmas/RS">
        </div>
        <div class="form-group">
          <label class="form-label">Catatan</label>
          <textarea class="form-textarea" name="notes"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RemindersModule.saveImmunization()">Simpan</button>
    `;

        Modal.create('Tambah Jadwal Imunisasi', content, { footer });
    },

    saveImmunization() {
        const form = document.getElementById('immunizationForm');
        const formData = new FormData(form);
        const immunizations = Storage.get('immunizations') || [];

        immunizations.push({
            id: Utils.generateId(),
            vaccine: formData.get('vaccine'),
            childName: formData.get('childName'),
            dueDate: formData.get('dueDate'),
            location: formData.get('location'),
            notes: formData.get('notes'),
            completed: false
        });

        Storage.set('immunizations', immunizations);
        Utils.showAlert('Jadwal imunisasi berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadImmunizations();
    },

    loadImmunizations() {
        const container = document.getElementById('immunizationList');
        if (!container) return;

        const immunizations = Storage.get('immunizations') || [];
        const upcoming = immunizations.filter(i => !i.completed);

        if (upcoming.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada jadwal imunisasi</p>';
            return;
        }

        container.innerHTML = upcoming.map(imm => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-syringe"></i> ${imm.vaccine}</h4>
          <p><strong>Anak:</strong> ${imm.childName}</p>
          <p><strong>Tanggal:</strong> ${Utils.formatDate(imm.dueDate)}</p>
          ${imm.location ? `<p><strong>Lokasi:</strong> ${imm.location}</p>` : ''}
          ${imm.notes ? `<p><strong>Catatan:</strong> ${imm.notes}</p>` : ''}
        </div>
        <div class="card-footer">
          <button class="btn btn-sm btn-success" onclick="RemindersModule.completeImmunization('${imm.id}')">
            <i class="fas fa-check"></i> Selesai
          </button>
          <button class="btn btn-sm btn-danger" onclick="RemindersModule.deleteImmunization('${imm.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    completeImmunization(id) {
        const immunizations = Storage.get('immunizations') || [];
        const imm = immunizations.find(i => i.id === id);
        if (imm) {
            imm.completed = true;
            Storage.set('immunizations', immunizations);
            Utils.showAlert('Imunisasi ditandai selesai', 'success');
            this.loadImmunizations();
        }
    },

    deleteImmunization(id) {
        if (!Utils.confirm('Hapus jadwal imunisasi ini?')) return;

        let immunizations = Storage.get('immunizations') || [];
        immunizations = immunizations.filter(i => i.id !== id);
        Storage.set('immunizations', immunizations);
        Utils.showAlert('Jadwal imunisasi berhasil dihapus', 'success');
        this.loadImmunizations();
    },

    // Routine
    addRoutine() {
        const content = `
      <form id="routineForm">
        <div class="form-group">
          <label class="form-label required">Jenis Pemeriksaan</label>
          <select class="form-select" name="type" required>
            <option value="">Pilih Jenis</option>
            <option value="Tekanan Darah">Tekanan Darah</option>
            <option value="Gula Darah">Gula Darah</option>
            <option value="Kolesterol">Kolesterol</option>
            <option value="Mata">Pemeriksaan Mata</option>
            <option value="Gigi">Pemeriksaan Gigi</option>
            <option value="Jantung">Pemeriksaan Jantung</option>
            <option value="Lainnya">Lainnya</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">Frekuensi</label>
          <select class="form-select" name="frequency" required>
            <option value="weekly">Mingguan</option>
            <option value="monthly">Bulanan</option>
            <option value="quarterly">3 Bulan Sekali</option>
            <option value="biannual">6 Bulan Sekali</option>
            <option value="annual">Tahunan</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">Tanggal Berikutnya</label>
          <input type="date" class="form-input" name="nextDate" required>
        </div>
        <div class="form-group">
          <label class="form-label">Catatan</label>
          <textarea class="form-textarea" name="notes"></textarea>
        </div>
      </form>
    `;

        const footer = `
      <button class="btn btn-secondary" onclick="Modal.close(this)">Batal</button>
      <button class="btn btn-primary" onclick="RemindersModule.saveRoutine()">Simpan</button>
    `;

        Modal.create('Tambah Pemeriksaan Rutin', content, { footer });
    },

    saveRoutine() {
        const form = document.getElementById('routineForm');
        const formData = new FormData(form);
        const routines = Storage.get('routines') || [];

        routines.push({
            id: Utils.generateId(),
            type: formData.get('type'),
            frequency: formData.get('frequency'),
            nextDate: formData.get('nextDate'),
            notes: formData.get('notes'),
            active: true
        });

        Storage.set('routines', routines);
        Utils.showAlert('Pemeriksaan rutin berhasil ditambahkan!', 'success');
        Modal.close(form);
        this.loadRoutines();
    },

    loadRoutines() {
        const container = document.getElementById('routineList');
        if (!container) return;

        const routines = Storage.get('routines') || [];
        const active = routines.filter(r => r.active);

        if (active.length === 0) {
            container.innerHTML = '<p class="text-center">Belum ada pemeriksaan rutin</p>';
            return;
        }

        const frequencyLabels = {
            weekly: 'Mingguan',
            monthly: 'Bulanan',
            quarterly: '3 Bulan Sekali',
            biannual: '6 Bulan Sekali',
            annual: 'Tahunan'
        };

        container.innerHTML = active.map(routine => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-stethoscope"></i> ${routine.type}</h4>
          <p><strong>Frekuensi:</strong> ${frequencyLabels[routine.frequency]}</p>
          <p><strong>Jadwal Berikutnya:</strong> ${Utils.formatDate(routine.nextDate)}</p>
          ${routine.notes ? `<p><strong>Catatan:</strong> ${routine.notes}</p>` : ''}
        </div>
        <div class="card-footer">
          <button class="btn btn-sm btn-danger" onclick="RemindersModule.deleteRoutine('${routine.id}')">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
      </div>
    `).join('');
    },

    deleteRoutine(id) {
        if (!Utils.confirm('Hapus pemeriksaan rutin ini?')) return;

        let routines = Storage.get('routines') || [];
        routines = routines.filter(r => r.id !== id);
        Storage.set('routines', routines);
        Utils.showAlert('Pemeriksaan rutin berhasil dihapus', 'success');
        this.loadRoutines();
    },

    checkReminders() {
        // This would check for upcoming reminders and show notifications
        // For demo purposes, we'll just log
        console.log('Checking reminders...');
    }
};
