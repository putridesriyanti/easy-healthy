// ===================================
// Education Module
// ===================================

window.EducationModule = {
    init() {
        this.render();
    },

    render() {
        const container = document.getElementById('educationContent');

        container.innerHTML = `
      <div class="tabs">
        <ul class="tab-list">
          <li><button class="tab-button active" onclick="EducationModule.showTab('articles')">Artikel</button></li>
          <li><button class="tab-button" onclick="EducationModule.showTab('videos')">Video</button></li>
          <li><button class="tab-button" onclick="EducationModule.showTab('tips')">Tips Sehat</button></li>
          <li><button class="tab-button" onclick="EducationModule.showTab('diseases')">Info Penyakit</button></li>
        </ul>
      </div>
      
      <!-- Articles Tab -->
      <div id="tab-articles" class="tab-content active">
        <div class="card mb-3">
          <div class="card-body">
            <input type="text" class="form-input" id="articleSearch" placeholder="Cari artikel..." onkeyup="EducationModule.searchArticles(this.value)">
          </div>
        </div>
        <div id="articlesList" class="grid grid-2"></div>
      </div>
      
      <!-- Videos Tab -->
      <div id="tab-videos" class="tab-content">
        <div id="videosList" class="grid grid-2"></div>
      </div>
      
      <!-- Tips Tab -->
      <div id="tab-tips" class="tab-content">
        <div id="tipsList"></div>
      </div>
      
      <!-- Diseases Tab -->
      <div id="tab-diseases" class="tab-content">
        <div class="card mb-3">
          <div class="card-body">
            <input type="text" class="form-input" id="diseaseSearch" placeholder="Cari penyakit..." onkeyup="EducationModule.searchDiseases(this.value)">
          </div>
        </div>
        <div id="diseasesList"></div>
      </div>
    `;

        this.loadArticles();
        this.loadVideos();
        this.loadTips();
        this.loadDiseases();
    },

    showTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-button');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    },

    articles: [
        { id: 1, title: 'Pentingnya Olahraga Rutin untuk Kesehatan Jantung', category: 'Jantung', readTime: 5, content: 'Olahraga rutin sangat penting untuk menjaga kesehatan jantung...' },
        { id: 2, title: 'Cara Mencegah Diabetes dengan Pola Makan Sehat', category: 'Diabetes', readTime: 7, content: 'Diabetes dapat dicegah dengan mengatur pola makan...' },
        { id: 3, title: 'Tips Menjaga Kesehatan Mental di Era Digital', category: 'Mental', readTime: 6, content: 'Kesehatan mental sama pentingnya dengan kesehatan fisik...' },
        { id: 4, title: 'Manfaat Tidur Cukup untuk Sistem Imun', category: 'Imunitas', readTime: 4, content: 'Tidur yang cukup membantu memperkuat sistem kekebalan tubuh...' },
        { id: 5, title: 'Panduan Lengkap Hidrasi yang Tepat', category: 'Nutrisi', readTime: 5, content: 'Air adalah komponen penting untuk tubuh yang sehat...' },
        { id: 6, title: 'Mengenal Gejala Awal Hipertensi', category: 'Jantung', readTime: 6, content: 'Hipertensi sering disebut silent killer karena...' }
    ],

    loadArticles(filter = '') {
        const container = document.getElementById('articlesList');
        if (!container) return;

        let articles = this.articles;
        if (filter) {
            articles = articles.filter(a =>
                a.title.toLowerCase().includes(filter.toLowerCase()) ||
                a.category.toLowerCase().includes(filter.toLowerCase())
            );
        }

        container.innerHTML = articles.map(article => `
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">${article.title}</h4>
        </div>
        <div class="card-body">
          <span class="badge badge-primary">${article.category}</span>
          <span class="badge badge-info"><i class="fas fa-clock"></i> ${article.readTime} menit</span>
          <p class="mt-2">${article.content}</p>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary btn-sm" onclick="EducationModule.readArticle(${article.id})">
            <i class="fas fa-book-open"></i> Baca Selengkapnya
          </button>
        </div>
      </div>
    `).join('');
    },

    searchArticles(query) {
        this.loadArticles(query);
    },

    readArticle(id) {
        const article = this.articles.find(a => a.id === id);
        if (!article) return;

        const content = `
      <div class="article-content">
        <span class="badge badge-primary">${article.category}</span>
        <span class="badge badge-info"><i class="fas fa-clock"></i> ${article.readTime} menit</span>
        <p class="mt-3">${article.content}</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
        <h4>Kesimpulan</h4>
        <p>Menjaga kesehatan adalah investasi terbaik untuk masa depan Anda.</p>
      </div>
    `;

        const footer = `
      <button class="btn btn-primary" onclick="Modal.close(this)">Tutup</button>
    `;

        Modal.create(article.title, content, { footer });
    },

    videos: [
        { id: 1, title: 'Cara Cuci Tangan yang Benar', duration: '3:45', url: 'https://www.youtube.com/watch?v=example1' },
        { id: 2, title: 'Senam Jantung Sehat 10 Menit', duration: '10:20', url: 'https://www.youtube.com/watch?v=example2' },
        { id: 3, title: 'Panduan Pertolongan Pertama', duration: '15:30', url: 'https://www.youtube.com/watch?v=example3' },
        { id: 4, title: 'Yoga untuk Pemula', duration: '20:00', url: 'https://www.youtube.com/watch?v=example4' }
    ],

    loadVideos() {
        const container = document.getElementById('videosList');
        if (!container) return;

        container.innerHTML = this.videos.map(video => `
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">${video.title}</h4>
        </div>
        <div class="card-body">
          <div style="background: var(--dark-gray); height: 200px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; margin-bottom: var(--spacing-md);">
            <i class="fas fa-play-circle" style="font-size: 4rem; color: var(--white);"></i>
          </div>
          <p><i class="fas fa-clock"></i> Durasi: ${video.duration}</p>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary btn-sm" onclick="window.open('${video.url}', '_blank')">
            <i class="fab fa-youtube"></i> Tonton di YouTube
          </button>
        </div>
      </div>
    `).join('');
    },

    tips: [
        { id: 1, title: 'Minum Air Putih 8 Gelas Sehari', content: 'Tubuh membutuhkan hidrasi yang cukup untuk fungsi optimal semua organ.' },
        { id: 2, title: 'Tidur 7-8 Jam Setiap Malam', content: 'Tidur yang cukup membantu regenerasi sel dan memperkuat sistem imun.' },
        { id: 3, title: 'Konsumsi Sayur dan Buah Setiap Hari', content: 'Minimal 5 porsi sayur dan buah untuk memenuhi kebutuhan vitamin dan mineral.' },
        { id: 4, title: 'Olahraga Minimal 30 Menit Sehari', content: 'Aktivitas fisik rutin membantu menjaga berat badan ideal dan kesehatan jantung.' },
        { id: 5, title: 'Kelola Stres dengan Baik', content: 'Praktikkan meditasi, yoga, atau hobi yang menyenangkan untuk mengurangi stres.' },
        { id: 6, title: 'Cuci Tangan Secara Teratur', content: 'Mencuci tangan dengan sabun dapat mencegah penyebaran penyakit.' }
    ],

    loadTips() {
        const container = document.getElementById('tipsList');
        if (!container) return;

        container.innerHTML = this.tips.map((tip, index) => `
      <div class="card mb-2">
        <div class="card-body">
          <h4><i class="fas fa-lightbulb" style="color: var(--warning);"></i> ${tip.title}</h4>
          <p>${tip.content}</p>
        </div>
      </div>
    `).join('');
    },

    diseases: [
        { id: 1, name: 'Diabetes Melitus', symptoms: 'Sering haus, sering buang air kecil, penurunan berat badan', prevention: 'Jaga pola makan, olahraga rutin, hindari gula berlebih', treatment: 'Kontrol gula darah, obat diabetes, insulin jika diperlukan' },
        { id: 2, name: 'Hipertensi', symptoms: 'Sakit kepala, pusing, pandangan kabur, sesak napas', prevention: 'Kurangi garam, olahraga, kelola stres, hindari rokok', treatment: 'Obat antihipertensi, perubahan gaya hidup' },
        { id: 3, name: 'Asma', symptoms: 'Sesak napas, mengi, batuk, dada terasa berat', prevention: 'Hindari pemicu (debu, asap, alergen), jaga kebersihan', treatment: 'Inhaler, obat pengontrol asma, hindari pemicu' },
        { id: 4, name: 'Gastritis', symptoms: 'Nyeri ulu hati, mual, muntah, kembung', prevention: 'Makan teratur, hindari makanan pedas, kurangi stres', treatment: 'Antasida, obat penurun asam lambung, pola makan sehat' },
        { id: 5, name: 'Kolesterol Tinggi', symptoms: 'Sering tanpa gejala, kadang pusing atau nyeri dada', prevention: 'Diet rendah lemak, olahraga, hindari makanan berlemak', treatment: 'Obat penurun kolesterol, perubahan diet' }
    ],

    loadDiseases(filter = '') {
        const container = document.getElementById('diseasesList');
        if (!container) return;

        let diseases = this.diseases;
        if (filter) {
            diseases = diseases.filter(d =>
                d.name.toLowerCase().includes(filter.toLowerCase()) ||
                d.symptoms.toLowerCase().includes(filter.toLowerCase())
            );
        }

        container.innerHTML = diseases.map(disease => `
      <div class="card mb-2">
        <div class="card-header">
          <h3 class="card-title"><i class="fas fa-disease"></i> ${disease.name}</h3>
        </div>
        <div class="card-body">
          <p><strong>Gejala:</strong> ${disease.symptoms}</p>
          <p><strong>Pencegahan:</strong> ${disease.prevention}</p>
          <p><strong>Pengobatan:</strong> ${disease.treatment}</p>
        </div>
      </div>
    `).join('');
    },

    searchDiseases(query) {
        this.loadDiseases(query);
    }
};
