# 📱 Panduan Install Easy Healthy App

Aplikasi Easy Healthy dapat diinstall di **semua device** seperti aplikasi native!

---

## 🖥️ Install di Windows / Mac / Linux (Desktop)

### Google Chrome / Microsoft Edge

1. **Buka aplikasi** di browser:
   - Jika sudah download: Buka file `index.html` atau `start.html`
   - Jika online: Buka URL aplikasi

2. **Install aplikasi**:
   - **Cara 1**: Klik tombol **"Install App"** yang muncul di pojok kanan bawah
   - **Cara 2**: Klik icon **install** (⊕) di address bar sebelah kanan
   - **Cara 3**: Klik menu (⋮) → **"Install Easy Healthy..."**

3. **Selesai!** Aplikasi akan:
   - Terbuka di window terpisah (seperti app native)
   - Muncul di Start Menu / Applications
   - Bisa di-pin ke taskbar/dock

### Mozilla Firefox

1. Buka aplikasi di Firefox
2. Klik menu (☰) → **"Install Easy Healthy"**
3. Confirm instalasi

### Safari (Mac)

1. Buka aplikasi di Safari
2. Klik menu **Share** → **"Add to Dock"**

---

## 📱 Install di Android

### Chrome / Edge / Samsung Internet

1. **Buka aplikasi** di browser mobile
2. **Install aplikasi**:
   - **Cara 1**: Klik tombol **"Install App"** di layar
   - **Cara 2**: Tap menu (⋮) → **"Add to Home screen"** atau **"Install app"**

3. **Konfirmasi** instalasi
4. **Selesai!** Icon aplikasi akan muncul di home screen

### Tips:
- Aplikasi akan buka fullscreen seperti app native
- Tidak ada address bar browser
- Bisa diakses dari app drawer

---

## 🍎 Install di iPhone / iPad (iOS)

### Safari (Required)

> ⚠️ **PENTING**: Di iOS, PWA hanya bisa diinstall via Safari, bukan Chrome!

1. **Buka aplikasi** di Safari
2. Tap tombol **Share** (kotak dengan panah ke atas) di bottom bar
3. Scroll dan pilih **"Add to Home Screen"**
4. Edit nama jika perlu, tap **"Add"**
5. **Selesai!** Icon muncul di home screen

### Catatan iOS:
- Aplikasi akan buka fullscreen
- Data tersimpan lokal di device
- Update otomatis saat buka aplikasi

---

## 💾 Download untuk Offline

### Cara Download ZIP

1. **Download file** `easy-healthy-pwa.zip`
2. **Extract** ZIP ke folder pilihan Anda
3. **Buka** file `index.html` atau `start.html`
4. **Install** mengikuti panduan di atas sesuai device

### Isi Package:
```
easy-healthy-pwa/
├── index.html          # File utama
├── start.html          # Launcher
├── manifest.json       # PWA config
├── sw.js              # Service worker
├── install.js         # Install handler
├── app.js             # App logic
├── styles.css         # Styling
├── assets/            # Icons & images
├── modules/           # Feature modules
└── INSTALL-GUIDE.md   # Panduan ini
```

---

## ✅ Verifikasi Instalasi

Setelah install, cek:

- ✅ Icon aplikasi muncul di home screen / start menu
- ✅ Aplikasi buka di window terpisah (bukan tab browser)
- ✅ Tidak ada address bar (fullscreen)
- ✅ Aplikasi tetap jalan **tanpa internet**

---

## 🔄 Update Aplikasi

Aplikasi akan **otomatis update** saat:
1. Anda buka aplikasi
2. Ada versi baru tersedia
3. Notifikasi update akan muncul
4. Klik **"Refresh"** untuk update

---

## 🗑️ Uninstall Aplikasi

### Windows / Mac / Linux:
- **Chrome/Edge**: Settings → Apps → Easy Healthy → Uninstall
- **Atau**: Klik kanan icon app → Uninstall

### Android:
- Long press icon → **Uninstall**
- Atau: Settings → Apps → Easy Healthy → Uninstall

### iOS:
- Long press icon → **Remove App** → **Delete App**

---

## ❓ Troubleshooting

### Tombol "Install App" tidak muncul?

**Penyebab:**
- Aplikasi sudah terinstall
- Browser tidak support PWA (gunakan Chrome/Edge/Safari)
- Aplikasi dibuka dari file:// (beberapa browser)

**Solusi:**
- Cek apakah sudah terinstall
- Gunakan browser yang support PWA
- Atau gunakan local server (lihat LOCAL-SERVER-GUIDE.md)

### Aplikasi tidak jalan offline?

**Penyebab:**
- Service worker belum teregister
- Cache belum lengkap

**Solusi:**
1. Buka aplikasi dengan internet
2. Tunggu beberapa detik (loading cache)
3. Refresh halaman
4. Coba offline mode

### Data hilang setelah update?

**Penyebab:**
- Browser cache di-clear

**Solusi:**
- Gunakan fitur **Backup** di menu Keamanan
- Export data secara berkala

### iOS: Aplikasi tidak bisa diinstall?

**Penyebab:**
- Menggunakan Chrome/Firefox (tidak support di iOS)

**Solusi:**
- **HARUS** menggunakan Safari di iOS
- Follow panduan iOS di atas

---

## 💡 Tips & Trik

### Akses Cepat:
- **Windows**: Pin ke taskbar
- **Mac**: Pin ke dock
- **Android**: Tambahkan widget
- **iOS**: Letakkan di home screen utama

### Backup Data:
1. Buka menu **Keamanan**
2. Klik **Export Data**
3. Simpan file backup
4. Restore kapan saja dengan **Import Data**

### Multi-Device:
- Install di semua device Anda
- Data tersimpan lokal per device
- Gunakan Export/Import untuk sync manual

---

## 🎉 Selamat!

Anda sekarang punya aplikasi kesehatan lengkap yang:
- ✅ Bisa diakses offline
- ✅ Seperti aplikasi native
- ✅ Aman dan privat
- ✅ Gratis selamanya!

**Nikmati Easy Healthy! 💚**
